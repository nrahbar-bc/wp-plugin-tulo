# Tulo Payway and Paywall WordPress Plugin

## Description

The **Tulo Payway and Paywall** plugin integrates Tulo functionalities into WordPress. This plugin enables paywall and payment gateway features using Tulo services, allowing site owners to manage premium content effectively.

## Features

- **Paywall Integration**: Manage and restrict access to premium content.
- **Payment Gateway**: Facilitate secure transactions through Tulo Payway.
- **Customizable Settings**: Configure the plugin to suit your website's needs.

## Installation

1. **Upload the Plugin Files**:
   - Extract the `wp-tulo-payway-paywall.zip` file.
   - Upload the extracted folder to the `/wp-content/plugins/` directory.

2. **Activate the Plugin**:
   - Navigate to the 'Plugins' menu in WordPress.
   - Find 'Tulo Payway and Paywall' in the list and click 'Activate'.

## Configuration

After activation, you can configure the plugin settings by following these steps:

1. Go to the WordPress admin dashboard.
2. Navigate to `Core Settings` > `Tulo Payway and Paywall Settings`.
3. Configure the necessary options such as API keys, payment settings, and paywall rules.
4. Add 2 template parts via site editor for "Login Button" & "Profile Button" and add their slug into thge plugin settings. You can use these templates.

**Login Button Template:**
```
[tulo_authentication_buttons]
```

## Usage

- **Meta Field**: Change the value of `Is Premium?` meta field in the post editor.
- **Shortcodes**: Use the provided shortcodes to control paywall functionalities within your posts or pages.
```
[paywall_limit] {{ PAYWALL LIMIT }} [tulo_authentication_buttons] [tulo_payway_login_form] [tulo_payway_register_form]
```

## Development

### File Structure

- **`assets/`**: Contains CSS, JS, and image assets.
- **`bc-fields/`**: Includes additional custom fields and assets.
- **`src/`**: Main source code for the plugin.
  - **`Config/`**: Configuration files.
  - **`Controllers/`**: Controllers for handling various functionalities.
  - **`Metafields/`**: Custom meta fields.
  - **`Models/`**: Data models.
  - **`Shortcodes/`**: Shortcode implementations.
  - **`Traits/`**: PHP traits.
- **`vendor/`**: Composer dependencies.
- **`wp-tulo-payway-paywall.php`**: Main plugin file.

### Composer

The plugin uses Composer for dependency management. To install the required dependencies, run:

```bash
composer install
```

For more details, visit the [GitHub repository](https://github.com/BetterCollective/bc-scraps/tree/master/wp-tulo-payway-paywall).

## License

This plugin is licensed under the [MIT License](https://opensource.org/licenses/MIT).

---
