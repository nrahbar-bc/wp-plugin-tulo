# BC Fields

BC Fields is a library for devs to speed up adding and manipulating fields. 

For the first version it will focus on metaboxes.

## Instalation

Copy the `bc-fields` forlder into the **root** folder of your theme or child theme (can't copy to both). Go to the 
copied folder `bc-fields` and run `composer install` command in your terminal.

In your theme `functions.php` file paste this:
```php
/**
 * BC custom fields
 */
require_once get_stylesheet_directory() . '/bc-fields/autoload.php';
```

## Usage

#### Instalation

Please finish the installation process described in this file. 

#### Create a new class for each metabox

Than create a new class under the `src/controllers` folder and extend the `\BCFields\Facades\BCFieldsMetabox` 
class from this library. The IDE will prompt you to create `init` method where you can register the new 
metabox and all the needed fields.

For the reference, please see the example 
[ExampleMetaboxController](https://github.com/BetterCollective/bc-scraps/blob/task/CORE-88/bc-fields/example/ExampleMetaboxController.php) 
class file in this library. You can also copy the example to your child theme and edit the file.

#### Call the created `init` method

In your `\BCCoreThemeChild\ChildThemeMain` class, in the `__construct()` method, call the created metabox class `init` 
method no later than `admin_init` WP action hook. It is recommended to use the `init` hook if you are not highly 
in WordPress. 

It is also recommended to call the init method only on admin pages as we don't need to register the fields on the 
frontend. There we will just pull data from post_meta table.

```php
// We don't need to add fields on frontend, just read post_meta there
if (! is_admin()) {
    return;
}

ExampleMetaboxController::getInstance()->init();
```

#### Add fields dynamically

You can add fields using the created metabox class before or after you call the `init` method. It is recommended to 
keep all the fields inside the metabox class you created to allow future developers to easily find them.

Example how to add a new field outside the created metabox class and perform some logic:

```php
// One way to add fields using general WP hooks
add_action('admin_head', function () {
    global $post_type;

    // Add field only for the post, even if we registered metabox for the post type
    if ('post' !== $post_type) {
        return;
    }

    ExampleMetaboxController::getInstance()->addInputTextField(
        'prefix_input_text_field_2',
        esc_html__('Example input text field', 'textdomain')
    );
});
```
It is recommended to **keep this dynamic added fields in the same metabox class** for the ease of the code understanding.

You can view WordPress [action hooks reference here](https://codex.wordpress.org/Plugin_API/Action_Reference)
 
The latest hook you can use to add fields is: `bcfields_metabox_prerender_{metabox_id}`

```php
// Fire just before rendering the metabox
add_action('bcfields_metabox_prerender_example_metabox_id', function () {

    // Display only for posts with id 7
    if (get_the_ID() != 7) {
        return;
    }

    ExampleMetaboxController::getInstance()->addInputTextField(
        'prefix_input_text_field_2',
        esc_html__('Example input text field', 'textdomain')
    );
});
```

#### Get the field value from the database

When you create the metabox class and extend library class, it will inherit some methods. One of them is 
the `getFieldValue` method which accepts Post ID as the first parameter and meta_key, the name for the field you 
registered. 

```php
/**
 * Retrieve the field value from the database
 * @param int $postId Post object ID
 * @param string $name Name of the field (meta_key)
 * @return mixed
 */
public function getFieldValue($postId, $name);
```

The example:

`ExampleMetaboxController::getInstance()->getFieldValue($postId, 'meta_key')`

It is recommended to use the created metabox class method and avoid calling the get_post_meta directly.

## Using the repeater field

To add some fields to the repeater field, you first need to call the `startRepeaterField` method and than add all the 
fields for the repeater as you would normaly add them. When you are done adding the fields, you **must 
call the `endRepeaterField` method** to stop adding fields to the repeater.

## Available fields

#### Input text field

```php
/**
 * Add input text field
 * @param string $name Input field name
 * @param string $title Input field title
 * @param string $description Field description
 * @return $this
 */
public function addInputTextField(
    string $name,
    string $title,
    string $description = ''
)
```

#### Textarea field

```php
/**
 * Add Textarea field
 * @param string $name Textarea field name
 * @param string $title Textarea field title
 * @param string $description Textarea description
 * @return $this
 */
public function addTextareaField(
    string $name,
    string $title,
    string $description = ''
)
```

#### WP Editor field
**Important**: This field is not supported by the Repeater

```php
/**
 * Add WP Editor field
 * This field is not supported by the Repeater
 * @param string $name Editor field name
 * @param string $title Editor field title
 * @param string $description Editor description
 * @return $this
 */
public function addWpEditorField(
    string $name,
    string $title,
    string $description = ''
)
```

#### Select field

We can select only one select value. This is not multiselect field.

```php
/**
 * Add select field with single selected value
 * @param string $name Select field name
 * @param string $title Select field title
 * @param array $options Array of options in format [value => text, value2 => text2]. 
                         The key will always be converted to string
 * @param string $description Field description
 * @return $this
 */
public function addSelectField(
    string $name,
    string $title,
    array $options,
    string $description = ''
)
```
#### Checkbox field

```php
/**
 * Add checkbox field with one value. The saved value in db will be string: if checked 1 else 0.
 * @param string $name Checkbox field name
 * @param string $title Checkbox field title
 * @param string $description Checkbox field description
 * @return $this
 */
public function addCheckboxField(
    string $name,
    string $title,
    string $description = ''
)
```

#### Image uploader field

```php
/**
 * Add image uploader field. The image id is saved in post_meta.
 * @param string $name Image uploader field name
 * @param string $title Image uploader field title
 * @param string $description Image uploader description
 * @return $this
 */
public function addImageUploaderField(
    string $name,
    string $title,
    string $description = ''
)
```

#### Repeater field

```php
/**
 * Start accepting new fields and store them as repeater fields
 * @param string $name Repeater field name
 * @param string $title Repeater field title
 * @param string $description Repeater field description
 * @return $this
 */
public function startRepeaterField(
    string $name,
    string $title,
    string $description = ''
)

/**
 * Stop storing new fields as repeater fields
 * @return $this
 */
public function endRepeaterField()
```

#### Date picker field

```php
/**
 * Add date picker field
 * @param string $name Date picker field name
 * @param string $title Date picker field title
 * @param string $description Field description
 * @return FacadeExternalUsageMethodsInterface
 */
public function addDatePickerField(
    string $name,
    string $title,
    string $description = ''
);
```

#### Time picker field

```php
/**
* Add time picker field
* @param string $name Time picker field name
* @param string $title Time picker field title
* @param string $description Field description
* @return FacadeExternalUsageMethodsInterface
*/
public function addTimePickerField(
string $name,
string $title,
string $description = ''
);
```

#### Date & Time picker field

```php
/**
 * Add datetime picker field
 * @param string $name DateTime picker field name
 * @param string $title DateTime picker field title
 * @param string $description Field description
 * @return FacadeExternalUsageMethodsInterface
 */
public function addDateTimePickerField(
    string $name,
    string $title,
    string $description = ''
);
```

## Action and filter hooks

### Action hooks

#### Fired before we render the metabox fields

```php
/**
 * @hook bcfields_metabox_prerender_{metabox_id}
 * @param FacadeInterface $facadeInstance
 * @param \WP_Post $post
 */
do_action(
    sprintf('bcfields_metabox_prerender_%s', $this->id),
    $this->facadeInstance, // Your created metabox class instance
    $post
);
```

#### Fired after we render the metabox fields

```php
/**
 * @hook bcfields_metabox_after_render_{metabox_id}
 * @param FacadeInterface $facadeInstance
 * @param \WP_Post $post
 */
do_action(
    sprintf('bcfields_metabox_after_render_%s', $this->id),
    $this->facadeInstance, // Your created metabox class instance
    $post
)
```

### Filter hooks

#### Filter registered fields for the metabox

```php
/**
 * @hook bcfields_metabox_fields_{metabox_id}
 * @param array $registeredFields All registered field for the current class instance
 */
return apply_filters(
    sprintf('bcfields_metabox_fields_%s', $this->id),
    $this->facadeInstance->getFieldsArray()
);
```

#### Filter field before it is saved to the database

```php
/**
 * @hook bcfields_model_save_field_{meta_key}
 * @param mixed $value Value passed to the model
 * @param int $postId Post object id
 */
$value = apply_filters(
    sprintf(
        'bcfields_model_save_field_%s',
        $metaKey
    ),
    $value,
    $postId
);
```

#### Filter field value just after it is fetched from DB and before it is returned

```php
/**
 * @hook bcfields_model_get_field_{meta_key}
 * @param string $metaKey Registered field name that is actually meta_key in the post_meta table
 * @param int $postId Post object id
 */
return apply_filters(
    sprintf(
        'bcfields_model_get_field_%s',
        $metaKey
    ),
    get_post_meta($postId, $metaKey, true),
    $postId
);
```

## Library development

This section contains instructions for the devs that are working on this library.

### Add new field steps

1. Add new method in the facade `\BCFields\Facades\BCFieldsMetabox` and 
Interface `BCFields\Contracts\FacadeExternalUsageMethodsInterface` named `add{field type}Field`. For example please 
 check the existing method: `addInputTextField`.
   * All the field methods in the Facade must only add to fields array using the Facade method `addField` and 
   return `$this` so we can chain the methods later.
   * Example: For this field we would only use `$name`, `$title`, and `$description` but we need to comply with the 
   add field method and pass also other params that we don't use in our example. 
   
   ```php
    public function add{fieldType}Field(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => {fieldType}FieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for example field, but it is needed for select field to pass options
            ]
        );

        return $this;
    }```
   
2. Add new class in the Namespace `\BCFields\Controllers\Fields` with the name: `{field type}FieldController` and
extend the `\BCFields\Controllers\FieldsController` abstract class. Use the parameters you defined in step 1.
   * Please keep the same css naming structure. 
        * For the field wrapper please use css classes `bcfields__field bcfields__field--{field type}`. 
        * For the field css id and css class
        * Add unique string to the label for and input id attribute to avoid browser complaining about multiple ids
please use `bcfields__select-{name parameter}`
3. Please make sure that all newly added classes and methods contain PHP Doc comments
4. Write unit tests (still not implemented)
5. Add info or changes to the README.md file
6. Change library version in the `bc-fields/autoload.php` file and `\BCFields\Config\BaseConfig` property.

## Changelog

 * 0.1.0 - Date 19.03.2020.
    * initial version
 * 0.2.0 - Date 19.05.2020.
    * Added textarea field
    * Changed logic to call each field class sanitize method in the repeater field.
 * 0.3.0 - Date 23.07.2021.
    * Added date picker field
    * Added time picker field
    * Added datetime picker field

## TODO
* Log errors in multiple files
* Write unit tests
