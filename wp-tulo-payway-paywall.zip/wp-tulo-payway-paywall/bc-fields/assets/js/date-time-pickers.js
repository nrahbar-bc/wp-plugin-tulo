/**
 * BC Fields Date, Time and DateTime picker fields
 */
(function ($) {

  "use strict";

  document.addEventListener('DOMContentLoaded', function () {

    // Date field
    $('.bcfields__field--date-picker').each(function() {
      const dateInputField = $(this).children('.flatpickr-date-input');
      flatpickr(dateInputField);
    });

    // Time field
    $('.bcfields__field--time-picker').each(function() {
      const timeInputField = $(this).children('.flatpickr-time-input');
      flatpickr(timeInputField, {
        noCalendar: true,
        enableTime: true,
        time_24hr: true
      });
    });

    // DateTime field
    $('.bcfields__field--datetime-picker').each(function() {
      const datetimeInputField = $(this).children('.flatpickr-datetime-input');
      flatpickr(datetimeInputField, {
        enableTime: true,
        time_24hr: true
      });
    });

  });

})(jQuery);
