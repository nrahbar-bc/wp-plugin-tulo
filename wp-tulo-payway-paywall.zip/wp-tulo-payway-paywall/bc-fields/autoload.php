<?php
/**
 * Class BCFieldsSetup
 * Version: 0.2.0
 */

// Already included
if (defined('BCFIELDS_AUTOLOAD')) {
    return;
}

define('BCFIELDS_AUTOLOAD', true);

require_once __DIR__ . '/vendor/autoload.php';
