<?php

namespace BCFields\Config;

use BCFields\Traits\SingletonTrait;

/**
 * Class BaseConfig represents library basic config
 * @package BCFields\Config
 */
class BaseConfig
{
    use SingletonTrait;

    /**
     * Library version
     * @var string
     */
    protected $version = '0.3.0';

    /**
     * Root url of the library.
     * @var string
     */
    private $rootUrl;

    /**
     * BaseConfig constructor.
     */
    private function __construct()
    {
        $this->rootUrl = get_theme_file_uri('bc-fields');
    }

    /**
     * Return library textdomain
     * @return string
     */
    public function getTextDomain()
    {
        return 'bc-fields';
    }

    /**
     * Return assets url without backslash at the end
     * @return string
     */
    public function getAssetsUrl()
    {
        return $this->rootUrl . '/assets';
    }

    /**
     * Return library version
     * @return string
     */
    public function getVersion()
    {
        return $this->version;
    }
}
