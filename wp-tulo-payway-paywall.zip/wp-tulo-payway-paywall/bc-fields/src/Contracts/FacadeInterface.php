<?php

namespace BCFields\Contracts;

/**
 * Interface FacadeInterface used for all facades
 * @package BCFields\Contracts
 */
interface FacadeInterface
{
    /**
     * Return registered fields array
     * @return array
     */
    public function getFieldsArray();
}
