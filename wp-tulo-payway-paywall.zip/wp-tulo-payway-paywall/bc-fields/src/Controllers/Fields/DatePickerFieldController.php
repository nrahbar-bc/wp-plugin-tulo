<?php

namespace BCFields\Controllers\Fields;

use BCFields\Controllers\FieldsController;

/**
 * Class DatePickerFieldController represent date picker field
 * @package BCFields\Controllers\Fields
 */
class DatePickerFieldController extends FieldsController
{
    // Not using $this->args for this field

    /**
     * @inheritDoc
     */
    public function render()
    {
        // Apply this to $this->name to get css class, id or other without repeater extra chars
        $cssSelector = $this->getCssSelector(
            sprintf(
                'bcfields__date-picker-%s',
                sanitize_text_field($this->name)
            )
        );

        return sprintf(
            '<section class="bcfields__field bcfields__field--date-picker">
                <label for="%1$s">%4$s</label>
                <input type="text" id="%1$s" class="flatpickr-date-input" name="%2$s" value="%3$s" placeholder="Select Date..." />
                %5$s
            </section>',
            sprintf(
                '%s_%s',
                $cssSelector,
                uniqid()
            ), // Avoid browser console complaining about multiple ids // %1$s
            sanitize_text_field($this->name), // %2$s
            self::sanitizeValue($this->value), // %3$s
            esc_html($this->title), // %4$s
            $this->getFieldDescriptionHtml($this->description) // %5$s
        );
    }

    /**
     * Sanitize input value
     * @param string $value
     * @return string
     */
    public static function sanitizeValue($value)
    {
        return sanitize_text_field($value);
    }

    /**
     * @inheritDoc
     */
    public static function checkRepeaterFieldSupport()
    {
        return true;
    }
}
