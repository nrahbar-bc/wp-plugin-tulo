<?php

namespace BCFields\Facades;

use BCFields\Config\BaseConfig;
use BCFields\Contracts\FacadeExternalUsageMethodsInterface;
use BCFields\Contracts\FacadeInterface;
use BCFields\Controllers\Fields\CheckboxFieldController;
use BCFields\Controllers\Fields\ImageUploaderFieldController;
use BCFields\Controllers\Fields\InputTextFieldController;
use BCFields\Controllers\Fields\RepeaterFieldController;
use BCFields\Controllers\Fields\SelectSingleFieldController;
use BCFields\Controllers\Fields\TextareaFieldController;
use BCFields\Controllers\Fields\WpEditorFieldController;
use BCFields\Controllers\Fields\DatePickerFieldController;
use BCFields\Controllers\Fields\TimePickerFieldController;
use BCFields\Controllers\Fields\DateTimePickerFieldController;
use BCFields\Controllers\MetaboxAPiController;
use BCFields\Models\MetaboxModel;
use BCFields\Traits\SingletonAbstractClassTrait;

/**
 * Class BCFieldsMetabox used to interact with this library
 * @package BCFields\Facades
 */
abstract class BCFieldsMetabox implements FacadeInterface, FacadeExternalUsageMethodsInterface
{
    use SingletonAbstractClassTrait;

    /**
     * Contain all registered fields
     * @var array
     */
    private $fields = [];

    /**
     * Containt class to interact with WP Metabox API
     * @var MetaboxAPiController
     */
    private $metaboxAPI;

    /**
     * Indicate if we started adding fields to the repeater field
     * @var bool
     */
    private $addingToRepeater = false;

    /**
     * Library textdomain
     * @var string
     */
    private $textDomain;

    /**
     * BCFieldsMetabox constructor.
     */
    protected function __construct()
    {
        $this->metaboxAPI = new MetaboxAPiController(MetaboxModel::getInstance());
        $this->textDomain = BaseConfig::getInstance()->getTextDomain();
    }

    /**
     * Retrieve the field value from the database
     * @param int $postId Post object ID
     * @param string $name Name of the field (meta_key)
     * @return mixed
     */
    public function getFieldValue($postId, $name)
    {
        return $this->metaboxAPI->getFieldValue(
            $postId,
            $this->sanitizeFieldName($name)
        );
    }

    /**
     * Add input text field
     * @param string $name Input field name
     * @param string $title Input field title
     * @param string $description Field description
     * @return BCFieldsMetabox
     */
    public function addInputTextField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => InputTextFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for input
            ]
        );

        return $this;
    }

    /**
     * Add Textarea field
     * @param string $name Textarea field name
     * @param string $title Textarea field title
     * @param string $description Textarea description
     * @return BCFieldsMetabox
     */
    public function addTextareaField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => TextareaFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for textarea
            ]
        );

        return $this;
    }

    /**
     * Add WP Editor field
     * This field is not supported by the Repeater
     * @param string $name Editor field name
     * @param string $title Editor field title
     * @param string $description Editor description
     * @return BCFieldsMetabox
     */
    public function addWpEditorField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => WpEditorFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for Editor field
            ]
        );

        return $this;
    }

    /**
     * Add select field with single selected value
     * @param string $name Select field name
     * @param string $title Select field title
     * @param array $options Array of options in format [value => text, value2 => text2]
     *                       The key will always be converted to string
     * @param string $description Field description
     * @return BCFieldsMetabox
     */
    public function addSelectField(
        string $name,
        string $title,
        array $options,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => SelectSingleFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [
                    'options' => $options // Options
                ]
            ]
        );

        return $this;
    }

    /**
     * Add checkbox field with one value. The saved value in db will be string: if checked 1 else 0.
     * @param string $name Checkbox field name
     * @param string $title Checkbox field title
     * @param string $description Checkbox field description
     * @return BCFieldsMetabox
     */
    public function addCheckboxField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => CheckboxFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => []
            ]
        );

        return $this;
    }

    /**
     * Add image uploader field. The image id is saved in post_meta.
     * @param string $name Image uploader field name
     * @param string $title Image uploader field title
     * @param string $description Image uploader description
     * @return BCFieldsMetabox
     */
    public function addImageUploaderField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => ImageUploaderFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for input
            ]
        );

        return $this;
    }

    /**
     * Start accepting new fields and store them as repeater fields
     * @param string $name Repeater field name
     * @param string $title Repeater field title
     * @param string $description Repeater field description
     * @return BCFieldsMetabox
     */
    public function startRepeaterField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => RepeaterFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [
                    'fields' => [] // Fields
                ],
            ]
        );

        $this->addingToRepeater = true;

        return $this;
    }

    /**
     * Stop storing new fields as repeater fields
     * @return BCFieldsMetabox
     */
    public function endRepeaterField()
    {
        $this->addingToRepeater = false;

        return $this;
    }

    /**
     * Add date picker field
     * @param string $name Date picker field name
     * @param string $title Date picker field title
     * @param string $description Field description
     * @return BCFieldsMetabox
     */
    public function addDatePickerField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => DatePickerFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for date picker
            ]
        );

        return $this;
    }

    /**
     * Add time picker field
     * @param string $name Time picker field name
     * @param string $title Time picker field title
     * @param string $description Field description
     * @return BCFieldsMetabox
     */
    public function addTimePickerField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => TimePickerFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for time picker
            ]
        );

        return $this;
    }

    /**
     * Add datetime picker field
     * @param string $name DateTime picker field name
     * @param string $title DateTime picker field title
     * @param string $description Field description
     * @return BCFieldsMetabox
     */
    public function addDateTimePickerField(
        string $name,
        string $title,
        string $description = ''
    ) {
        $this->addField(
            [
                'class_name'  => DateTimePickerFieldController::class,
                'name'        => $this->sanitizeFieldName($name),
                'title'       => $title,
                'description' => $description,
                'args'        => [] // Not needed for datetime picker
            ]
        );

        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getFieldsArray()
    {
        return $this->fields;
    }

    /**
     * Register metabox using the add_meta_boxes hook and add save metabox callback.
     *          We can add more fields to the metabox intance after we call this method.
     * @param string $id Id for the metabox
     * @param string $title Title of the meta box.
     * @param array $screens Array of post types to display metabox.
     * @param string $context Available: normal | side | advanced.
     *        The context within the screen where the boxes should display.
     * @param string $priority Available: default | high | low
     * @return BCFieldsMetabox
     */
    public function register(
        string $id,
        string $title,
        array $screens,
        string $context = 'normal',
        string $priority = 'default'
    ) {
        $this->metaboxAPI->setRequiredProperties(
            $id,
            $title,
            $screens,
            $context,
            $priority,
            $this
        );

        add_action('add_meta_boxes', [$this->metaboxAPI, 'add']);
        foreach ($screens as $screen) {
            add_action(
                sprintf(
                    'save_post_%s',
                    // Use same sanitizer here to comply with the one in MetaboxApiController class
                    sanitize_text_field($screen)
                ),
                [$this->metaboxAPI, 'save']
            );
        }

        return $this;
    }

    /**
     * Return all registered fields for the current class instance
     * @param array $args Field arguments
     */
    private function addField(array $args)
    {
        if (! $this->addingToRepeater) {
            // WPCS ok. All fields are sanitized in their own class before any output
            $this->fields[] = $args;

            return;
        }

        // Discard not supported Repeater fields before we add them to the registered fields array
        if (! call_user_func([$args['class_name'], 'checkRepeaterFieldSupport'])) {
            trigger_error(
                sprintf(
                    esc_html__('Field: %s is not allowed in the Repeater'),
                    $args['class_name']
                ),
                E_USER_NOTICE
            );

            return;
        }

        end($this->fields);
        $this->fields[key($this->fields)]['args']['fields'][] = $args;
        reset($this->fields);
    }

    /**
     * Apply strtolower and sanitize_text_field function, replace '-' and spaces with '_';
     * @param string $name Field name
     * @return string
     */
    private function sanitizeFieldName($name)
    {
        return str_replace(['-', ' '], '_', strtolower(sanitize_file_name($name)));
    }
}
