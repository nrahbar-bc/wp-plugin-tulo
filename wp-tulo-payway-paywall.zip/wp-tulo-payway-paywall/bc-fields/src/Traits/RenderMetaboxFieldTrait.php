<?php

namespace BCFields\Traits;

use BCFields\Contracts\FieldInterface;

/**
 * Trait RenderMetaboxFieldTrait used to render field class output for single fields and inside a repeater
 * @package BCFields\Traits
 */
trait RenderMetaboxFieldTrait
{
    /**
     * Render each field for the metabox content
     * @param array $args Field arguments array that are defined in the BCFields\Facades\BCFieldsMetabox
     *                    facade method for every field definition. Array must contain this keys:
     *                     [
     *                      'class_name'  => {fieldClass}::class,
     * 'name'        => $name,
     * 'title'       => $title,
     * 'description' => $description,
     * 'args'        => []
     *                     ]
     * @param mixed $value Post object ID
     * @return string Field rendered html as string
     */
    protected function renderFieldArgs($args, $value)
    {
        // For Repeater Fields
        if(isset($args['repeater']) && !empty($args['repeater'])) {
            if(is_array($value)) {
                $newValue[$args['repeater']['field_name']] = array_values($value)[0];
            }
        }
        return $this->renderField(
            new $args['class_name'](
                $args['name'],
                $args['title'],
                (isset($newValue)) ? $newValue[$args['repeater']['field_name']] : $value,
                $args['description'],
                $args['args']
            )
        );
    }

    /**
     * Render field class html output as string
     * @param FieldInterface $fieldClassName Field class instance
     * @return string Field rendered html as string
     */
    private function renderField(FieldInterface $fieldClassName)
    {
        return $fieldClassName->render();
    }
}
