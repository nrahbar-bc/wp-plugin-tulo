<?php

namespace TuloPaywayPaywall\Admin;

/**
 * class SoccernewsSettingsPage
 */
class TuloSettingsPage {
    public const OPTION_GROUP_TULO = 'wp_tulo_payway_paywall_options';
    public const PAYWAY_API_CLIENT = 'payway_api_client';
    public const PAYWAY_API_SECRET = 'payway_api_secret';
    public const PAYWAY_API_URL = 'payway_api_url';
    public const PAYWAY_REDIRECT_URL = 'payway_redirect_url';
    public const PAYWAY_ORGANIZATION_ID = 'payway_organization_id';
    public const PAYWAY_PRODUCT_KEY = 'payway_product_key';
    public const PAYWAY_PAYWALL_KEY = 'payway_paywal_key';
    public const PAYWAY_PROFILE_URL = 'payway_profile_url';
    public const PAYWAY_REGISTER_URL = 'payway_register_url';
    public const PAYWAY_FORGOT_URL = 'payway_forgot_url';
    public const PAYWAY_SHOP_URL = 'payway_shop_url';
    public const PAYWALL_API_KEY = 'paywall_api_key';
    public const PAYWALL_API_SECRET = 'paywall_api_secret';
    public const PAYWALL_API_URL = 'paywall_api_url';
    public const PAYWALL_TITLE = 'paywall_title';
    public const TULO_LOGIN_SLUG = 'tulo_login_slug';
    public const TULO_PROFILE_SLUG = 'tulo_profile_slug';
    public const TULO_CLIENT_AREA = 'tulo_client_area';
    public const TULO_DESKTOP_AD = 'tulo_desktop_ad';
    public const TULO_MOBILE_AD = 'tulo_mobile_ad';
    public const TULO_LOGIN_CLASSES = 'tulo_login_classes';
    public const RUDDERSTACK_WRITE_KEY = 'rudderstack_write_key';

    /**
     * SettingsPage constructor
     */
    public function __construct()
    {
        add_action('admin_init', [$this, 'registerTuloSettings']);
        add_action('admin_menu', [$this, 'buildAdminSubmenu'], 30);
    }

    /**
     * @return void
     */
    public function registerTuloSettings()
    {

        // Tulo
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_API_CLIENT);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_API_SECRET);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_API_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_REDIRECT_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_ORGANIZATION_ID);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_PRODUCT_KEY);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_PAYWALL_KEY);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_PROFILE_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_REGISTER_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_FORGOT_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWAY_SHOP_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWALL_API_KEY);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWALL_API_SECRET);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWALL_API_URL);
        register_setting(self::OPTION_GROUP_TULO, self::PAYWALL_TITLE);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_LOGIN_SLUG);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_PROFILE_SLUG);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_CLIENT_AREA);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_DESKTOP_AD);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_MOBILE_AD);
        register_setting(self::OPTION_GROUP_TULO, self::TULO_LOGIN_CLASSES);
        register_setting(self::OPTION_GROUP_TULO, self::RUDDERSTACK_WRITE_KEY);
    }

    /**
     * @return void
     */
    public function buildAdminSubmenu()
    {
        add_submenu_page(
            'core-settings',
            __('Tulo Payway & Paywall Settings', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN, 'wp-tulo-payway-paywall'),
            __('Tulo Payway & Paywall Settings', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN, 'wp-tulo-payway-paywall'),
            'manage_options',
            'tulo-settings',
            [$this, 'renderTuloSettingsPage']
        );
    }

    /**
     * @return void
     */
    public function renderTuloSettingsPage()
    {
        include_once 'views/tulo-settings-page.php';
    }
}
