<?php

if (!defined('ABSPATH')) {
    exit;
}

use TuloPaywayPaywall\Admin\TuloSettingsPage;
?>

<div class="wrap">
    <h2><?php echo __('Tulo Settings', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN, 'wp-tulo-payway-paywall'); ?></h2>
    <?php
    settings_errors();
    $wrapperStart = '<form action="options.php" method="post"><table class="form-table">';
    $wrapperEnd = '</table>' . get_submit_button() . '</form>';
    do_action('form_message');
    echo $wrapperStart;
    settings_fields(TuloSettingsPage::OPTION_GROUP_TULO);
    do_settings_sections(TuloSettingsPage::OPTION_GROUP_TULO);
    include_once 'tulo-tab.php';
    echo $wrapperEnd;
    ?>
</div>
