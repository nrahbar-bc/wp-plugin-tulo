<?php
if (!defined('ABSPATH')) {
    exit;
}

use TuloPaywayPaywall\Models\TuloSettings;
use TuloPaywayPaywall\Admin\TuloSettingsPage;
?>
<style>
	input.text-field{
		width: 300px;
		padding: 7px;
		border-radius: 5px;
		border: 1px solid #ccc;
	}
</style>
<h2>Tulo Settings</h2>
<tr><td colspan="4" style="padding-left: 0;"><h3 style="margin: 0;">Payway Settings</h3></td></tr>
<tr valign="top">
    <th scope="row"><?php echo __('Payway API Client', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywayApiClient = TuloSettings::getInstance()->paywayApiClient;
        $paywayApiClientData = esc_attr(TuloSettingsPage::PAYWAY_API_CLIENT);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $paywayApiClientData; ?>"
            name="<?php echo $paywayApiClientData; ?>"
            value="<?php echo $paywayApiClient ?>">
        </div>
    </td>

	<th scope="row"><?php echo __('Payway API Secret', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayApiSecret = TuloSettings::getInstance()->paywayApiSecret;
		$paywayApiSecretData = esc_attr(TuloSettingsPage::PAYWAY_API_SECRET);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayApiSecretData; ?>"
			       name="<?php echo $paywayApiSecretData; ?>"
			       value="<?php echo $paywayApiSecret ?>">
		</div>
	</td>
</tr>
<tr valign="top">
    <th scope="row"><?php echo __('Payway API URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywayApiUrl = TuloSettings::getInstance()->paywayApiUrl;
        $paywayApiUrlData = esc_attr(TuloSettingsPage::PAYWAY_API_URL);
        ?>
        <div class="bc-custom-field">
	        <select class="text-field" id="<?php echo $paywayApiUrlData; ?>"
	                name="<?php echo $paywayApiUrlData; ?>">
		        <option
			        <?php echo ($paywayApiUrl == 'https://payway-api.stage.adeprimo.se') ? 'selected' : '' ?>
			        value="https://payway-api.stage.adeprimo.se" title="https://payway-api.stage.adeprimo.se">Staging</option>
		        <option
			        <?php echo ($paywayApiUrl == 'https://backend.worldoftulo.com') ? 'selected' : '' ?>
			        value="https://backend.worldoftulo.com" title="https://backend.worldoftulo.com">Production</option>
	        </select>
        </div>
    </td>

	<th scope="row"><?php echo __('Payway Redirect Url', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayRedirectUrl = TuloSettings::getInstance()->paywayRedirectUrl;
		$paywayRedirectUrlData = esc_attr(TuloSettingsPage::PAYWAY_REDIRECT_URL);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayRedirectUrlData; ?>"
			       name="<?php echo $paywayRedirectUrlData; ?>"
			       value="<?php echo $paywayRedirectUrl ?>">
		</div>
	</td>
</tr>
<tr valign="top">
    <th scope="row"><?php echo __('Payway Organization ID', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywayOrganizationId = TuloSettings::getInstance()->paywayOrganizationId;
        $paywayOrganizationIdData = esc_attr(TuloSettingsPage::PAYWAY_ORGANIZATION_ID);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $paywayOrganizationIdData; ?>"
            name="<?php echo $paywayOrganizationIdData; ?>"
            value="<?php echo $paywayOrganizationId ?>">
        </div>
    </td>

	<th scope="row"><?php echo __('Payway Product Key', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayProductKey = TuloSettings::getInstance()->paywayProductKey;
		$paywayProductKeyData = esc_attr(TuloSettingsPage::PAYWAY_PRODUCT_KEY);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayProductKeyData; ?>"
			       name="<?php echo $paywayProductKeyData; ?>"
			       value="<?php echo $paywayProductKey ?>">
		</div>
	</td>
</tr>
<tr><td colspan="4"><hr style="width: 50%; height: 2px; background-color:#c4c4c4;"></td></tr>
<tr><td colspan="4" style="padding-left: 0; padding-top: 0;"><h3 style="margin: 0;">Paywall Settings</h3></td></tr>
<tr valign="top">
    <th scope="row"><?php echo __('Payway Paywall Key', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywayPaywallKey = TuloSettings::getInstance()->paywayPaywallKey;
        $paywayPaywallKeyData = esc_attr(TuloSettingsPage::PAYWAY_PAYWALL_KEY);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $paywayPaywallKeyData; ?>"
            name="<?php echo $paywayPaywallKeyData; ?>"
            value="<?php echo $paywayPaywallKey ?>">
        </div>
    </td>

	<th scope="row"><?php echo __('Paywall API Key', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywallApiKey = TuloSettings::getInstance()->paywallApiKey;
		$paywallApiKeyData = esc_attr(TuloSettingsPage::PAYWALL_API_KEY);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywallApiKeyData; ?>"
			       name="<?php echo $paywallApiKeyData; ?>"
			       value="<?php echo $paywallApiKey ?>">
		</div>
	</td>
</tr>
<tr valign="top">
    <th scope="row"><?php echo __('Paywall API Secret', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywallApiSecret = TuloSettings::getInstance()->paywallApiSecret;
        $paywallApiSecretData = esc_attr(TuloSettingsPage::PAYWALL_API_SECRET);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $paywallApiSecretData; ?>"
            name="<?php echo $paywallApiSecretData; ?>"
            value="<?php echo $paywallApiSecret ?>">
        </div>
    </td>

	<th scope="row"><?php echo __('Paywall API URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywallApiUrl = TuloSettings::getInstance()->paywallApiUrl;
		$paywallApiUrlData = esc_attr(TuloSettingsPage::PAYWALL_API_URL);
		?>
		<div class="bc-custom-field">
			<select class="text-field" id="<?php echo $paywallApiUrlData; ?>"
			        name="<?php echo $paywallApiUrlData; ?>">
				<option
					<?php echo ($paywallApiUrl == 'https://payway-paywall-stage.adeprimo.se') ? 'selected' : '' ?>
					value="https://payway-paywall-stage.adeprimo.se" title="https://payway-paywall-stage.adeprimo.se">Staging</option>
				<option
					<?php echo ($paywallApiUrl == 'https://paywall.worldoftulo.com') ? 'selected' : '' ?>
					value="https://paywall.worldoftulo.com" title="https://paywall.worldoftulo.com">Production</option>
			</select>
		</div>
	</td>
</tr>
<tr valign="top">
    <th scope="row"><?php echo __('Paywall Title', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $paywallTitle = TuloSettings::getInstance()->paywallTitle;
        $paywallTitleData = esc_attr(TuloSettingsPage::PAYWALL_TITLE);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $paywallTitleData; ?>"
            name="<?php echo $paywallTitleData; ?>"
            value="<?php echo $paywallTitle ?>">
        </div>
    </td>
</tr>
<tr><td colspan="4"><hr style="width: 50%; height: 2px; background-color:#c4c4c4;"></td></tr>
<tr><td colspan="4" style="padding-left: 0; padding-top: 0;"><h3 style="margin: 0;">Tulo General Information</h3></td></tr>
<tr>
	<th scope="row"><?php echo __('Payway Profile URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayProfileUrl = TuloSettings::getInstance()->paywayProfileUrl;
		$paywayProfileUrlData = esc_attr(TuloSettingsPage::PAYWAY_PROFILE_URL);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayProfileUrlData; ?>"
			       name="<?php echo $paywayProfileUrlData; ?>"
			       value="<?php echo $paywayProfileUrl ?>"
			       placeholder="/mitt-konto/">
		</div>
	</td>

	<th scope="row"><?php echo __('Payway Registration URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayRegisterUrl = TuloSettings::getInstance()->paywayRegisterUrl;
		$paywayRegisterUrlData = esc_attr(TuloSettingsPage::PAYWAY_REGISTER_URL);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayRegisterUrlData; ?>"
			       name="<?php echo $paywayRegisterUrlData; ?>"
			       value="<?php echo $paywayRegisterUrl ?>"
			       placeholder="/skapa-konto/">
		</div>
	</td>
</tr>
<tr valign="top">
	<th scope="row"><?php echo __('Tulo Login Button template slug', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$tuloLoginSlug = TuloSettings::getInstance()->tuloLoginSlug;
		$tuloLoginSlugData = esc_attr(TuloSettingsPage::TULO_LOGIN_SLUG);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $tuloLoginSlugData; ?>"
			       name="<?php echo $tuloLoginSlugData; ?>"
			       value="<?php echo $tuloLoginSlug ?>"
			       placeholder="login-button">
		</div>
	</td>

	<th scope="row"><?php echo __('Payway Forgot Password URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayForgotUrl = TuloSettings::getInstance()->paywayForgotUrl;
		$paywayForgotUrlData = esc_attr(TuloSettingsPage::PAYWAY_FORGOT_URL);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayForgotUrlData; ?>"
			       name="<?php echo $paywayForgotUrlData; ?>"
			       value="<?php echo $paywayForgotUrl ?>"
			       placeholder="/glomt-losenord/">
		</div>
	</td>
</tr>
<tr valign="top">
    <th scope="row"><?php echo __('Tulo Profile Button template slug', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
    <td>
        <?php
        $tuloProfileSlug = TuloSettings::getInstance()->tuloProfileSlug;
        $tuloProfileSlugData = esc_attr(TuloSettingsPage::TULO_PROFILE_SLUG);
        ?>
        <div class="bc-custom-field">
            <input class="text-field" id="<?php echo $tuloProfileSlugData; ?>"
            name="<?php echo $tuloProfileSlugData; ?>"
            value="<?php echo $tuloProfileSlug ?>"
            placeholder="profile-button">
        </div>
    </td>

	<th scope="row"><?php echo __('Payway Client URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$tuloClientArea = TuloSettings::getInstance()->tuloClientArea;
		$tuloClientAreaData = esc_attr(TuloSettingsPage::TULO_CLIENT_AREA);
		?>
		<div class="bc-custom-field">
			<select class="text-field" id="<?php echo $tuloClientAreaData; ?>"
			        name="<?php echo $tuloClientAreaData; ?>">
				<option
					<?php echo ($tuloClientArea == 'https://everysportplus.payway-portal.stage.adeprimo.se') ? 'selected' : '' ?>
					value="https://everysportplus.payway-portal.stage.adeprimo.se" title="https://everysportplus.payway-portal.stage.adeprimo
					.se">Staging</option>
				<option
					<?php echo ($tuloClientArea == 'https://everysportplus.portal.worldoftulo.com') ? 'selected' : '' ?>
					value="https://everysportplus.portal.worldoftulo.com" title="https://everysportplus.portal.worldoftulo.com">Production</option>
			</select>
		</div>
	</td>
</tr>
<tr valign="top">
	<th scope="row"><?php echo __('Payway Shop URL', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$paywayShopUrl = TuloSettings::getInstance()->paywayShopUrl;
		$paywayShopUrlData = esc_attr(TuloSettingsPage::PAYWAY_SHOP_URL);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $paywayShopUrlData; ?>"
			       name="<?php echo $paywayShopUrlData; ?>"
			       value="<?php echo $paywayShopUrl ?>">
		</div>
	</td>

	<th scope="row"><?php echo __('Tulo Login Classes', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$tuloLoginClasses = TuloSettings::getInstance()->tuloLoginClasses;
		$tuloLoginClassesData = esc_attr(TuloSettingsPage::TULO_LOGIN_CLASSES);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $tuloLoginClassesData; ?>"
			       name="<?php echo $tuloLoginClassesData; ?>"
			       value="<?php echo $tuloLoginClasses ?>">
		</div>
	</td>
</tr>
<tr><td colspan="4"><hr style="width: 50%; height: 2px; background-color:#c4c4c4;"></td></tr>
<tr valign="top">
	<th scope="row"><?php echo __('RudderStack Write Key', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
        <?php
        $rudderstackWriteKey = TuloSettings::getInstance()->rudderstackWriteKey;
        $rudderstackWriteKeyData = esc_attr(TuloSettingsPage::RUDDERSTACK_WRITE_KEY);
        ?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $rudderstackWriteKeyData; ?>"
			       name="<?php echo $rudderstackWriteKeyData; ?>"
			       value="<?php echo $rudderstackWriteKey ?>"
			       placeholder="Write Key">
		</div>
	</td>
</tr>
<tr><td colspan="4"><hr style="width: 50%; height: 2px; background-color:#c4c4c4;"></td></tr>
<tr><td colspan="4" style="padding-left: 0; padding-top: 0;"><h3 style="margin: 0;">Injected Ads Information</h3></td></tr>
<tr valign="top">
	<th scope="row"><?php echo __('Desktop ad placeholder', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$tuloDesktopAd = TuloSettings::getInstance()->tuloDesktopAd;
		$tuloDesktopAdData = esc_attr(TuloSettingsPage::TULO_DESKTOP_AD);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $tuloDesktopAdData; ?>"
			       name="<?php echo $tuloDesktopAdData; ?>"
			       value="<?php echo $tuloDesktopAd ?>"
			       placeholder="Desktop ad placeholder">
		</div>
	</td>

	<th scope="row"><?php echo __('Mobile ad placeholder', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN) ?></th>
	<td>
		<?php
		$tuloMobileAd = TuloSettings::getInstance()->tuloMobileAd;
		$tuloMobileAdData = esc_attr(TuloSettingsPage::TULO_MOBILE_AD);
		?>
		<div class="bc-custom-field">
			<input class="text-field" id="<?php echo $tuloMobileAdData; ?>"
			       name="<?php echo $tuloMobileAdData; ?>"
			       value="<?php echo $tuloMobileAd ?>"
			       placeholder="Mobile ad placeholder">
		</div>
	</td>
</tr>
<script>
	const selectMenus = document.querySelectorAll('select');
	selectMenus.forEach((selectMenu) => {
		// Set the initial tooltip based on the first selected option
		selectMenu.title = selectMenu.options[selectMenu.selectedIndex].title;

		// Update the tooltip when the selected option changes
		selectMenu.addEventListener('change', function () {
			const selectedOption = this.options[this.selectedIndex];
			this.title = selectedOption.title;
		});
	});
</script>
