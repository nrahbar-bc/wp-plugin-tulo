<?php

namespace TuloPaywayPaywall\Config;

use TuloPaywayPaywall\Models\TuloSettings;
use TuloPaywayPaywall\Traits\SingletonTrait;

class TuloPaywallApi
{
    use SingletonTrait;

    public $apiKey;
    public $apiSecret;
    public $paywallTitle;
    public $paywayProductKey;
    public $paywallProductKey;
	public $shopUrl;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->apiKey = TuloSettings::getInstance()->paywallApiKey;
        $this->apiSecret = TuloSettings::getInstance()->paywallApiSecret;
        $this->paywallTitle = TuloSettings::getInstance()->paywallTitle;
        $this->paywayProductKey = TuloSettings::getInstance()->paywayProductKey;
        $this->paywallProductKey = TuloSettings::getInstance()->paywayPaywallKey;
		$this->shopUrl = TuloSettings::getInstance()->paywayShopUrl;
        add_action('wp_enqueue_scripts', [$this, 'enqueuePaywallScripts']);
        add_filter('script_loader_tag', [$this, 'addTypeAttribute'], 10, 3);
    }

    /**
     * @return void
     */
    public function enqueuePaywallScripts()
    {
        global $post;
        $postID = get_queried_object_id();
        $postCategory = '';
        
        if (isset($post->post_type) && $post->post_type === 'post') {
            $categories = wp_get_post_categories($postID, array('fields' => 'all'));
            if (!empty($categories) && isset($categories[0]->name)) {
                $postCategory = $categories[0]->name;
            }
        }

        $tuloRestrictions = (get_post_meta($postID, 'is_premium', true)) ? get_post_meta($postID, 'is_premium', true) : '0';

		$jsVersion = filemtime(
		TULO_PAYWAY_PAYWALL_DIR . '/assets/public/dist/js/tulo-paywall.min.js'
        );

        wp_register_script(
            'paywall-script',
            'https://payway-cdn.worldoftulo.com/js/1.3/paywall.js',
            [],
            $jsVersion
        );

        wp_register_script(
            'paywall-custom-script',
	        TULO_PAYWAY_PAYWALL_URL . 'assets/public/dist/js/tulo-paywall.min.js',
            ['paywall-script'],
            $jsVersion
        );

	    // JWT parameters
	    wp_localize_script(
		    'paywall-custom-script',
		    'paywall',
		    [
			    'siteUrl' => get_bloginfo('url'),
			    'apiKey' => $this->apiKey,
			    'apiSecret' => $this->apiSecret,
			    'title' => $this->paywallTitle,
			    'key' => $this->paywallProductKey,
			    'paywallApiUrl' => TuloSettings::getInstance()->paywallApiUrl,
			    'shop' => $this->shopUrl.
				    "?articleId=".$postID.
				    "&backUrl=".get_permalink($postID).'?order-completed'.
				    "&returnUrl=".get_permalink($postID).'?order-completed',
			    'returnUrl' => get_permalink($postID).'?order-completed',
			    'backUrl' => get_permalink($postID).'?order-completed',
			    'articleId' => $postID,
			    'categories' => $postCategory
		    ]
	    );

        wp_localize_script(
			'paywall-custom-script',
			'post',
			[
            'postRestriction' => $tuloRestrictions,
            'postID' => $postID,
            ]
        );

        wp_enqueue_script('paywall-script');
		wp_enqueue_script('paywall-jwt');
        wp_enqueue_script('paywall-custom-script');
    }

    public function addTypeAttribute($tag, $handle, $src)
    {
        // if not your script, do nothing and return original $tag
        if ('paywall-jwt' !== $handle) {
            return $tag;
        }
        // change the script tag by adding type="module" and return it.
        $tag = '<script type="module" src="' . esc_url($src) . '"></script>';
        return $tag;
    }

    public function strContainsMulti(string $haystack, array $needles)
    {
        foreach ($needles as $needle) {
            if (str_contains($haystack, $needle)) {
                return true;
            }
        }
        return false;
    }
}
