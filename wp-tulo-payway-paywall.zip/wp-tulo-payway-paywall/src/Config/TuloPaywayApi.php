<?php

namespace TuloPaywayPaywall\Config;

use TuloPaywayPaywall\Models\TuloSettings;
use TuloPaywayPaywall\Traits\SingletonTrait;

class TuloPaywayApi {
    use SingletonTrait;

    public string $paywayClientApi;
    public string $paywayClientSecret;
    public string $paywayApiUrl;
    public string $paywayOrganizationId;
    public string $paywayRedirectUrl;
    public string $userToken;

    public function __construct()
    {
        $this->paywayClientApi        = TuloSettings::getInstance()->paywayApiClient;
        $this->paywayClientSecret     = TuloSettings::getInstance()->paywayApiSecret;
        $this->paywayApiUrl           = TuloSettings::getInstance()->paywayApiUrl;
        $this->paywayOrganizationId   = TuloSettings::getInstance()->paywayOrganizationId;
        $this->paywayRedirectUrl      = TuloSettings::getInstance()->paywayRedirectUrl;

	    add_action('wp_ajax_getNewServiceToken', [$this, 'getNewServiceToken']);
	    add_action('wp_ajax_nopriv_getNewServiceToken', [$this, 'getNewServiceToken']);

		add_action('wp_ajax_getNewUserTokens', [$this, 'getNewUserTokens']);
	    add_action('wp_ajax_nopriv_getNewUserTokens', [$this, 'getNewUserTokens']);

		add_action('wp_ajax_refreshUserTokens', [$this, 'refreshUserTokens']);
	    add_action('wp_ajax_nopriv_refreshUserTokens', [$this, 'refreshUserTokens']);

		add_action('wp_ajax_getUserAccount', [$this, 'getUserAccount']);
	    add_action('wp_ajax_nopriv_getUserAccount', [$this, 'getUserAccount']);

		add_action('wp_ajax_successRemoteLogin', [$this, 'successRemoteLogin']);
	    add_action('wp_ajax_nopriv_successRemoteLogin', [$this, 'successRemoteLogin']);

		add_action('wp_ajax_requestLoginHandle', [$this, 'requestLoginHandle']);
	    add_action('wp_ajax_nopriv_requestLoginHandle', [$this, 'requestLoginHandle']);

		add_action('wp_ajax_successRemoteLogout', [$this, 'successRemoteLogout']);
	    add_action('wp_ajax_nopriv_successRemoteLogout', [$this, 'successRemoteLogout']);

		add_action('wp_ajax_updateAccount', [$this, 'updateAccount']);
	    add_action('wp_ajax_nopriv_updateAccount', [$this, 'updateAccount']);

		add_action('wp_ajax_getProduct', [$this, 'getProduct']);
	    add_action('wp_ajax_nopriv_getProduct', [$this, 'getProduct']);

		add_action('wp_ajax_getAccountPurchaseHistory', [$this, 'getAccountPurchaseHistory']);
	    add_action('wp_ajax_nopriv_getAccountPurchaseHistory', [$this, 'getAccountPurchaseHistory']);

		add_action('wp_ajax_updateUserPassword', [$this, 'updateUserPassword']);
	    add_action('wp_ajax_nopriv_updateUserPassword', [$this, 'updateUserPassword']);

		add_action('wp_ajax_createUserAccount', [$this, 'createUserAccount']);
	    add_action('wp_ajax_nopriv_createUserAccount', [$this, 'createUserAccount']);

//		add_action('wp_ajax_getCancellationReasons', [$this, 'getCancellationReasons']);
//	    add_action('wp_ajax_nopriv_getCancellationReasons', [$this, 'getCancellationReasons']);

//		add_action('wp_ajax_cancelAccountSubscription', [$this, 'cancelAccountSubscription']);
//	    add_action('wp_ajax_nopriv_cancelAccountSubscription', [$this, 'cancelAccountSubscription']);
    }

    /**
     * Method to fetch a new service token (you need to implement this based on your logic)
     *
     * @return mixed|string
     */
    public function getNewServiceToken()
    {
	    check_ajax_referer('getNewServiceToken_nonce', 'nonce', false);
        // Set up the request headers
        $headers = array(
            'Accept'       => 'application/json',
            'Content-Type' => 'application/x-www-form-urlencoded',
        );
        // Set up the request body
	    $body = array(
		    'grant_type'    => 'none',
		    'response_type'    => 'code',
		    'client_id'     => $this->paywayClientApi,
		    'client_secret' => $this->paywayClientSecret,
		    'redirect_uri' => $this->paywayRedirectUrl,
		    'oid' => $this->paywayOrganizationId,
		    'scope'         => '/external/account/r /external/account/w /external/me/r /external/me/w /external/me/update_password/w /oauth2/login/x /external/product/r',
		    'state' => $this->paywayRedirectUrl.'/logga-in/',
	    );
        // Make the request
        $response = wp_remote_post($this->paywayApiUrl . '/api/authorization/access_token', array(
            'headers' => $headers,
            'body'    => http_build_query($body),
        ));
        // Check for errors
        if (is_wp_error($response)) {
	        wp_send_json_error('Request failed.');
            return 'Request failed.';
        }
        $response_body = wp_remote_retrieve_body($response);
        $data          = json_decode($response_body, true);
	    if (defined('DOING_AJAX') && DOING_AJAX) {
			wp_send_json_success($response_body, 200);
		}
        return $data;
    }

    /**
     * Get a new Tulo Payway user token.
     *
     * @param  string  $userId
     * @param  string  $code
     *
     * @return array
     * @throws Exception
     */
    public function getNewUserTokens()
    {
	    check_ajax_referer('getNewUserTokens_nonce', 'nonce');
		$code = $_POST['tulo_code'];
	    // Set up the request headers
	    $headers = array(
		    'Accept'       => 'application/json',
		    'Content-Type' => 'application/x-www-form-urlencoded',
	    );

        // Set up the request body
        $body = array(
            'grant_type'    => 'authorization_code',
            'client_id'     => $this->paywayClientApi,
            'client_secret' => $this->paywayClientSecret,
            'code'          => $code,
            'redirect_uri'  => $this->paywayRedirectUrl,
        );
        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/api/authorization/access_token',
            array(
                'headers' => $headers,
                'body'    => $body,
            )
        );
        // Check for errors
        if (is_wp_error($response)) {
	        wp_send_json_error('Failed to get user access token: ' . $response->get_error_message());
            throw new Exception('Failed to get user access token: ' . $response->get_error_message());
        }
        // Retrieve and decode the response body
        $responseBody = wp_remote_retrieve_body($response);
        $data         = json_decode($responseBody, true);
        // Check if decoding failed or if the response indicates a failure
        if (json_last_error() !== JSON_ERROR_NONE || wp_remote_retrieve_response_code($response) !== 200 || empty($data['access_token'])) {
            if (isset($data['error']) && $data['error'] === 'invalid_grant') {
                wp_die(__('Invalid grant', 'wp-tulo-payway-paywall'), 400);
            }
	        wp_send_json_error('Failed to get user access token: ' . $response->get_error_message());
            throw new Exception('Failed to get user access token');
        }
        // Create the token array
        $token = array(
            'token'                => $data['access_token'],
            'refresh'              => $data['refresh_token'],
            'access_token_expires' => (new \DateTime())->add(new \DateInterval('PT' . $data['expires_in'] . 'S'))->format('Y-m-d H:i:s'),
        );
	    wp_send_json_success($responseBody, $response['data']['response']['code']);
        return $token;
    }

    /**
     * Refresh the Tulo Payway user access token.
     *
     * @param  string  $userId
     * @param  string  $refreshToken
     *
     * @return array
     * @throws Exception
     */
    public function refreshUserTokens()
    {
	    check_ajax_referer('refreshUserTokens_nonce', 'nonce');
	    $refreshToken = $_POST['refresh_token'];

        // Set up the request headers
        $headers = array(
            'Accept'       => 'application/json',
            'Content-Type' => 'application/x-www-form-urlencoded',
        );
        // Set up the request body
        $body = array(
            'grant_type'    => 'refresh_token',
            'refresh_token' => $refreshToken,
            'client_id'     => $this->paywayClientApi,
            'client_secret' => $this->paywayClientSecret,
            'redirect_uri'  => $this->paywayRedirectUrl,
            'scope'         => '/external/account/r /external/account/w /external/me/r /external/me/w /external/me/update_password/w /oauth2/login/x /external/product/r',
        );
        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/api/authorization/access_token',
            array(
                'headers' => $headers,
                'body'    => $body,
            )
        );
        // Check for errors
        if (is_wp_error($response)) {
	        wp_send_json_error('Failed to refresh user access token: ' . $response->get_error_message());
            throw new Exception('Failed to refresh user access token: ' . $response->get_error_message());
        }
        // Retrieve and decode the response body
        $responseBody = wp_remote_retrieve_body($response);
        $data         = json_decode($responseBody, true);
        // Check if decoding failed or if the response indicates a failure
        if (json_last_error() !== JSON_ERROR_NONE || wp_remote_retrieve_response_code($response) !== 200 || empty($data['access_token'])) {
	        wp_send_json_error('Failed to refresh user access token: ' . $response->get_error_message());
            throw new Exception('Failed to refresh user access token');
        }
	    wp_send_json_success($responseBody, $response['data']['response']['code']);
        return $responseBody;
    }

    /**
     * Get a user account from Tulo Payway.
     *
     * @param  string  $email
     *
     * @return array|null
     */
    public function getUserAccount(): ?array
    {
	    check_ajax_referer('getUserAccount_nonce', 'nonce', false);

	    if (!isset($_POST['email']) || !filter_var(urldecode($_POST['email']), FILTER_VALIDATE_EMAIL)) {
		    wp_send_json_error('Ogiltig e-postadress: '.urldecode($_POST['email']));
	    }

	    $email = urldecode($_POST['email']);
	    $token = urldecode($_POST['tulo_access_token']);

        $url = $this->paywayApiUrl . '/external/api/v1/accounts?email=' . sanitize_email($email);
        // Set up the request headers
        $headers = array(
            'Accept'        => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        );
        // Make the HTTP GET request
        $response = wp_remote_get($url, array(
            'headers' => $headers,
        ));

        // Check for errors
        if (is_wp_error($response)) {
	        wp_send_json_error('Fel e-postadress eller lösenord');
        }
        // Retrieve and decode the response body
        $response_body = $response['body'];
        $data          = json_decode($response_body, true);
        // Check if decoding failed or if the response indicates a failure
        if (json_last_error() !== JSON_ERROR_NONE || wp_remote_retrieve_response_code($response) !== 200) {
	        wp_send_json_error('Fel e-postadress eller lösenord');
        }
	    if (defined('DOING_AJAX') && DOING_AJAX) {
		    wp_send_json_success($response);
	    }
		return $data;
    }

    /**
     * Check if a user can successfully sign in to Tulo Payway.
     *
     * @param  string  $username
     * @param  string  $password
     * @param  boolean    $persist
     *
     * @return boolean
     */
    public function successRemoteLogin()
    {
	    check_ajax_referer('successRemoteLogin_nonce', 'nonce');

        $url = $this->paywayApiUrl . '/oauth2/login';
        // Set up the request headers
        $headers = array(
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/x-www-form-urlencoded',
            'Authorization' => 'OAuth ' . $_POST['tulo_access_token'],
        );
        // Set up the request body
        $body = array(
            'username' => urldecode($_POST['email']),
            'password' => urldecode($_POST['password']),
            'persist'  => true,
        );
        // Make the HTTP POST request
        $response = wp_remote_post($url, array(
            'headers' => $headers,
            'body'    => http_build_query($body),
        ));

        // Check for errors
        if (is_wp_error($response)) {
			wp_send_json_error('Fel e-postadress eller lösenord');
            return false;
        }
        // Retrieve and decode the response body
        $response_body = wp_remote_retrieve_body($response);
        $data          = json_decode($response_body, true);
        // Check if decoding failed or the response status is not 'ok'
        if (json_last_error() !== JSON_ERROR_NONE || $data['status'] !== 'ok') {
	        wp_send_json_error('Fel e-postadress eller lösenord');
            return false;
        }
	    wp_send_json_success(true);
        return true;
    }

    /**
     * Request a login handle from Tulo Payway.
     *
     * @param  string  $username
     * @param  string  $password
     * @param  string  $state
     * @param  boolean    $persist
     *
     * @return array
     * @throws Exception
     */
    public function requestLoginHandle(): array
    {
	    check_ajax_referer('requestLoginHandle_nonce', 'nonce');

		$state = wp_generate_uuid4();
        // Prepare headers and payload
        $headers = [
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/x-www-form-urlencoded',
            'Authorization' => 'Bearer ' . $_POST['tulo_access_token'],
        ];
        $payload = [
            'username' => urldecode($_POST['email']),
            'password' => urldecode($_POST['password']),
            'persist'  => true,
        ];
        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/oauth2/login',
            [
                'headers' => $headers,
                'body'    => $payload,
            ]
        );

        // Check if request failed or response is empty
        if (is_wp_error($response) || empty(wp_remote_retrieve_body($response))) {
			wp_send_json_error('Fel e-postadress eller lösenord', $response['response']['code']);
        }
        // Parse the response JSON
        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);
        if (empty($response_data['result'])) {
	        wp_send_json_error('Fel e-postadress eller lösenord', $response['response']['code']);
        }
        // Construct redirect URL
        $redirectUrl = $this->paywayApiUrl . '/oauth2/auth';
        $redirectUrl .= '?client_id=' . $this->paywayClientApi;
        $redirectUrl .= '&redirect_uri=' . $this->paywayRedirectUrl . '&state=' . $state;
        $redirectUrl .= '&response_type=code&oid=' . $this->paywayOrganizationId;
        $redirectUrl .= '&scope=/external/me/w /external/me/r /external/me/update_password/w /external/account/r /external/account/w /external/product/r';
        $redirectUrl .= '&login_handle=' . $response_data['result'];
        // Prepare the handle array
        $handle = [
            'status'      => 'SUCCESS',
            'redirectUrl' => $redirectUrl,
        ];
		wp_send_json_success(json_encode($handle));
        return $handle;
    }

	/**
	 * Check if a user can successfully sign in to Tulo Payway.
	 *
	 * @param  string  $username
	 * @param  string  $password
	 * @param  boolean    $persist
	 *
	 * @return boolean
	 */
	public function successRemoteLogout()
	{
		check_ajax_referer('successRemoteLogout_nonce', 'nonce');
		$url = $this->paywayApiUrl . '/oauth2/logout';
		// Make the HTTP GET request
		$response = wp_remote_get($url.'?continue=/logga-in/');
		$response_body = wp_remote_retrieve_body($response);
		wp_send_json_success(json_encode($response_body));
		return $response_body;
	}

    /**
     * Create a new user account in Tulo Payway.
     *
     * @param string $email
     * @param string $password
     * @return string
     * @throws Exception
     */
    public function createUserAccount(): array
    {
	    check_ajax_referer('createUserAccount_nonce', 'nonce');
        $token = urldecode($_POST['tulo_access_token']);


        // Prepare headers and payload
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ];
        $payload = [
            'email' => urldecode($_POST['email']),
            'password' => urldecode($_POST['password']),
            'first_name' => urldecode($_POST['first_name']),
            'last_name' => urldecode($_POST['last_name']),
            'account_origin' => 'emp',
        ];

        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/external/api/v1/accounts',
            [
                'headers' => $headers,
                'body' => json_encode($payload),
            ]
        );

        // Check if request failed
        if (is_wp_error($response)) {
			wp_send_json_error('Failed to create user account', $response['response']['code']);
            throw new \Exception('Failed to create user account');
        }

        // Return the created user account ID
        $response_body = wp_remote_retrieve_body($response);
		$data          = json_decode($response_body, true);

//        if (!isset($response_data['id'])) {
//            return wp_remote_retrieve_response_code($response); //$response['body'];
//        }

	    wp_send_json_success($response_body, $response['response']['code']);
        return $data;
    }

    /**
     * Request a password reset token for an existing account.
     *
     * @param string $email
     * @return null|string
     * @throws Exception
     */
    public function requestPasswordResetToken(string $email): ?string
    {
        $token = $this->getNewServiceToken();

        // Prepare headers and payload
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token['access_token'],
        ];
        $payload = [
            'email' => $email,
        ];

        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/external/api/v1/accounts/create_password_reset',
            [
                'headers' => $headers,
                'body' => json_encode($payload),
            ]
        );

        // Check if request failed due to too many attempts
        if (wp_remote_retrieve_response_code($response) == 409) {
	        echo "<script>
			(() => {
				window.addEventListener('DOMContentLoaded', event => {
					const alertBox = document.getElementById('tuloPaywayResetPasswordFormAlert');
					const errorMessage = alertBox.querySelector('p');
					errorMessage.innerHTML = 'För många lösenordsåterställningsförsök för e-post: '.$email;
					alertBox.classList.replace('alert-success', 'alert-danger');
					alertBox.classList.replace('d-none', 'show');
				});
			})();
			</script>";
            return null;
        }

        // Check if request was successful and retrieve confirmation code
        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (!$response_data || empty($response_data['item']['confirmation_code'])) {
	        echo "<script>
			(() => {
				window.addEventListener('DOMContentLoaded', event => {
					const alertBox = document.getElementById('tuloPaywayResetPasswordFormAlert');
					const errorMessage = alertBox.querySelector('p');
					errorMessage.innerHTML = 'E-post kunde inte hittas';
					alertBox.classList.replace('alert-success', 'alert-danger');
					alertBox.classList.replace('d-none', 'show');
				});
			})();
			</script>";
            return null;
        }

        return $response_data['item']['confirmation_code'];
    }

    /**
     * Complete a password reset in Tulo Payway.
     *
     * @param string $paywayId
     * @param string $confirmationCode
     * @param string $password
     * @return boolean
     * @throws Exception
     */
    public function completePasswordReset(string $accountId, string $confirmationCode, string $password): bool
    {
        $token = $this->getNewServiceToken();

        // Prepare headers and payload
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token['access_token'],
        ];
        $payload = [
            'id' => $accountId,
            'confirmation_code' => $confirmationCode,
            'new_password' => $password,
        ];

        // Make the HTTP POST request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/external/api/v1/accounts/complete_password_reset',
            [
                'headers' => $headers,
                'body' => json_encode($payload),
            ]
        );
        // Check if request was successful
        if (wp_remote_retrieve_response_code($response) === 200) {
            return true;
        }

        return false;
    }

    /**
     * Update a user account in Tulo Payway.
     *
     * @param string $accountId
     * @param array $data
     * @return boolean
     * @throws Exception
     */
    public function updateAccount()
    {
	    check_ajax_referer('updateAccount_nonce', 'nonce');

        $token = $_POST['tulo_access_token'];
		$accountId = $_POST['tulo_account_id'];
	    $data['first_name'] = urldecode($_POST['first_name']);
        $data['last_name'] = urldecode($_POST['last_name']);
        $data['email'] = urldecode($_POST['email']);
        $data['birth_date'] = urldecode($_POST['birth_date']);
        $data['mobile_phone_number'] = urldecode($_POST['mobile_phone_number']);
        $data['address']['street'] = urldecode($_POST['address']['street']);
	    $data['address']['street_number'] = urldecode($_POST['address']['street_number']);
	    $data['address']['zip_code'] = urldecode($_POST['address']['zip_code']);
	    $data['address']['city'] = urldecode($_POST['address']['city']);
	    $data['address']['country_code'] = urldecode($_POST['address']['country_code']);

		//unset($data['tulo_payway_nonce']);

        // Prepare headers and payload
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ];
        $payload = array_merge([
			'id' => $accountId,
        ], $data);

		$payload['address']['first_name'] = $payload['first_name'];
		$payload['address']['last_name'] = $payload['last_name'];
		$payload['address']['building'] = $payload['address']['street_number'];

        // Make the HTTP PUT request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/external/api/v1/accounts',
            [
                'method' => 'PUT',
                'headers' => $headers,
                'body' => json_encode($payload),
            ]
        );

		$response_body = wp_remote_retrieve_body($response);

	    if (wp_remote_retrieve_response_code($response) === 400) {
			wp_send_json_error($response_body, 400);
			return $response;
	    }
        // Check if request was successful
//        if (wp_remote_retrieve_response_code($response) === 200) {
//            return true;
//        }
	    wp_send_json_success($response_body);
        return $response;
    }

	public function getProduct() {
		check_ajax_referer('getProduct_nonce', 'nonce');

		$token = urldecode($_POST['tulo_user_access_token']);
		$productCode = urldecode($_POST['productCode']);

		// Getting product info
		$url = $this->paywayApiUrl . '/external/api/v1/products?product_code='.$productCode;
		$productHeaders = array(
			'Accept'        => 'application/json',
			'Authorization' => 'Bearer ' . $token,
		);
		// Make the HTTP GET request
		$response = wp_remote_get($url, array(
			'headers' => $productHeaders,
		));

		if (is_wp_error($response)) {
			return false;
		}
		$response_body = wp_remote_retrieve_body($response);
		$productData = json_decode($response_body, true);
		wp_send_json_success($response_body);
		return $productData;
	}

//	public function getCancellationReasons() {
//		$id = '5d31bec495cfeb2fd5897462';
//		$token = $_POST['tulo_access_token'];
//
//		// Getting user active product
//		$url = $this->paywayApiUrl . '/external/api/v1/cancellation_reasons?id='.$id;
//		$url .= '&include_internal=true';
//		$url .= '&visible_to_end_customer=true';
//		// Set up the request headers
//		$headers = array(
//			'accept'        => 'application/json',
//			'Content-Type' => 'application/json',
//			'Authorization' => 'Bearer ' . $token,
//		);
//		// Make the HTTP PUT request
//		$response = wp_remote_get($url, array(
//			'headers' => $headers,
//		));
//
//		if (is_wp_error($response)) {
//			return false;
//		}
//
//		$response_body = wp_remote_retrieve_body($response);
//		wp_send_json_success($response_body);
//		return $response_body;
//	}
//
//	public function cancelAccountSubscription() {
//		$tulo_access_token = $_POST['tulo_access_token'];
//		$account_id = $_POST['account_id'];
//		$user_product_id = $_POST['user_product_id'];
//		$cancellationReasonId = '5d31bec495cfeb2fd5897462';
//
//		// Getting user active product
//		$url = $this->paywayApiUrl . '/external/api/v1/subscription_system/cancel_subscription';
//		// Set up the request headers
//		$headers = array(
//			'Accept'        => 'application/json',
//			'Content-Type' => 'application/json',
//			'Authorization' => 'Bearer ' . $tulo_access_token,
//		);
//
//		$payload = [
//			'account_id' => $account_id,
//			'user_product_id' => $user_product_id,
//			'cancellation_reason_id' => $cancellationReasonId,
//		];
////		// Make the HTTP PUT request
//		$response = wp_remote_post($url, array(
//			'method' => 'PUT',
//			'headers' => $headers,
//			'body' => json_encode($payload),
//		));
//		echo '<pre class="custom-debug">' . print_r($response, true) . "</pre>";
//
//		if (is_wp_error($response)) {
//			return false;
//		}
//		$response_body = wp_remote_retrieve_body($response);
//		return json_decode($response_body, true);
//	}

	public function getAccountPurchaseHistory () {
		check_ajax_referer('getAccountPurchaseHistory_nonce', 'nonce');
		$token = urldecode($_POST['tulo_user_access_token']);

		$url = $this->paywayApiUrl . '/external/api/v1/me/get_purchase_history';
		// Set up the request headers
		$headers = array(
			'Accept'        => 'application/json',
			'Authorization' => 'Bearer ' . $token,
		);
		// Make the HTTP GET request
		$response = wp_remote_get($url, array(
			'headers' => $headers,
		));
		$response_body = wp_remote_retrieve_body($response);
		wp_send_json_success($response_body);
		return json_decode($response_body, true);
	}

    /**
     * Update a user's password in Tulo Payway.
     *
     * @param string $paywayId
     * @param string $oldPassword
     * @param string $newPassword
     * @return boolean
     * @throws Exception
     */
    public function updateUserPassword(): bool
    {
	    check_ajax_referer('updateUserPassword_nonce', 'nonce');
	    $token = $_POST['tulo_access_token'];
	    $oldPassword = urldecode($_POST['old_password']);
	    $newPassword = urldecode($_POST['password']);

        // Prepare headers and payload
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ];
        $payload = [
            'old_password' => $oldPassword,
            'new_password' => $newPassword,
        ];

        // Make the HTTP PUT request
        $response = wp_remote_post(
            $this->paywayApiUrl . '/external/api/v1/me/update_password',
            [
                'method' => 'PUT',
                'headers' => $headers,
                'body' => json_encode($payload),
            ]
        );
	    $body = wp_remote_retrieve_body($response);
		$body = json_decode($body, true);
        // Check if request was successful
        if (wp_remote_retrieve_response_code($response) === 200) {
	        wp_send_json_success("Om din e-postadress matchar med ett konto kommer du få ett mail med instruktioner.", 200);
            return true;
        }
	    wp_send_json_error($body['message']);
        return false;
    }

    /**
     * Archive a user account in Tulo Payway.
     *
     * @param string $paywayId
     * @return boolean
     * @throws Exception
     */
    public function archiveAccount(string $paywayId): bool
    {
        $token = $this->getServiceToken();

        // Prepare headers
        $headers = [
            'Accept' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ];

        // Make the HTTP DELETE request
        $response = wp_remote_request(
            $this->paywayApiUrl . '/external/api/v1/accounts/archive?account_id=' . $paywayId,
            [
                'method' => 'DELETE',
                'headers' => $headers,
            ]
        );

        // Check if request was successful
        if (wp_remote_retrieve_response_code($response) === 200) {
            return true;
        }

        return false;
    }
}
