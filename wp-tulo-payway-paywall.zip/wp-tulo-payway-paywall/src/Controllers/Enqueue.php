<?php

namespace TuloPaywayPaywall\Controllers;

use TuloPaywayPaywall\Models\TuloSettings;

/**
 * Class Enqueue
 */
class Enqueue {
    /**
     * Enqueue constructor.
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueueChildThemeStylesAndScripts']);
        add_filter('style_loader_tag', [$this, 'preloadFilter'], 10, 2);
        add_filter('script_loader_tag', [$this, 'deferParsingOfJs'], 10);
    }

	/**
	 * @return void
	 */
	public function enqueueChildThemeStylesAndScripts()
	{
		$this->loadChildThemeCSS();

		$jsVersionChild  = filemtime(
			TULO_PAYWAY_PAYWALL_DIR . '/assets/public/dist/js/tulo.min.js'
		);

		wp_register_script(
			'tulo-scripts',
			TULO_PAYWAY_PAYWALL_URL . '/assets/public/dist/js/tulo.min.js',
			[],
			$jsVersionChild,
			true
		);
		wp_localize_script(
			'tulo-scripts',
			'tulo',
			[
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonces'   => array(
					'getNewServiceToken' => wp_create_nonce('getNewServiceToken_nonce'),
					'getNewUserTokens'   => wp_create_nonce('getNewUserTokens_nonce'),
					'refreshUserTokens'   => wp_create_nonce('refreshUserTokens_nonce'),
					'getUserAccount'   => wp_create_nonce('getUserAccount_nonce'),
					'successRemoteLogin'   => wp_create_nonce('successRemoteLogin_nonce'),
					'requestLoginHandle'   => wp_create_nonce('requestLoginHandle_nonce'),
					'successRemoteLogout'   => wp_create_nonce('successRemoteLogout_nonce'),
					'updateAccount'   => wp_create_nonce('updateAccount_nonce'),
					'getProduct'   => wp_create_nonce('getProduct_nonce'),
					'getAccountPurchaseHistory'   => wp_create_nonce('getAccountPurchaseHistory_nonce'),
					'updateUserPassword'   => wp_create_nonce('updateUserPassword_nonce'),
					'createUserAccount'   => wp_create_nonce('createUserAccount_nonce'),
//					'getCancellationReasons'   => wp_create_nonce('getCancellationReasons_nonce'),
//					'cancelAccountSubscription'   => wp_create_nonce('cancelAccountSubscription_nonce'),
				),
                'rudderStackWriteKey' => $this->encodeBase64(TuloSettings::getInstance()->rudderstackWriteKey.":"),
				'remoteUrl' => TuloSettings::getInstance()->tuloClientArea,
				'paywayApiUrl' => TuloSettings::getInstance()->paywayApiUrl,
			]
		);
		wp_enqueue_script('tulo-scripts');
	}

    /**
     * @return void
     */
    public function loadChildThemeCSS()
    {
	    global $post;
		if(is_single()) {
			$tuloRestrictions = (get_post_meta($post->ID, 'is_premium', true)) ? get_post_meta($post->ID, 'is_premium', true) : '0';
			if (is_single($post->ID) && (has_tag('premium', $post->ID) || $tuloRestrictions != 0)) {
				$cssVersion = filemtime(
					TULO_PAYWAY_PAYWALL_DIR . '/assets/public/dist/css/tulo.min.css'
				);
				wp_enqueue_style(
					'tulo-styles',
					TULO_PAYWAY_PAYWALL_URL . '/assets/public/dist/css/tulo.min.css',
					[],
					$cssVersion
				);
			}
		}
    }

    public function deferParsingOfJs($url)
    {
        if (is_user_logged_in()) {
            return $url;
        }
        if (false === strpos($url, '.js')) {
            return $url;
        }
        if (strpos($url, 'jquery.js')) {
            return $url;
        }
        return str_replace(' src', ' defer src', $url);
    }

    public function preloadFilter($html, $handle)
    {
        if (strcmp($handle, 'preload-style') == 0) {
            $html = str_replace("rel='stylesheet'", "rel='preload' as='style' ", $html);
        }
        return $html;
    }
    
    public function encodeBase64($data) {
        return base64_encode($data);
    }
}
