<?php

namespace TuloPaywayPaywall\Controllers;

use TuloPaywayPaywall\Config\TuloPaywallApi;

class TuloPaywall {
    public function __construct()
    {
	    add_filter( 'body_class', [$this, 'addTagBodyClass'] );
        add_action('the_content', [$this, 'injectPaywallLimit'], 10);
        add_filter('the_content', array($this,'generateTuloShortcode'));
        add_action('rest_api_init', [$this, 'registerEndpoint']);
    }

	public function addTagBodyClass( $classes ) {
		global $post;
		if ( isset( $post ) ) {
			$tuloRestrictions = (get_post_meta($post->ID, 'is_premium', true)) ? get_post_meta($post->ID, 'is_premium', true) : '0';
			if(has_tag('premium', $post->ID) || $tuloRestrictions != 0) {
				$classes[] = 'premium-post';
			}
			$classes[] = 'premium-post_'.$tuloRestrictions;
		}
		return $classes;
	}

    public function injectPaywallLimit($content)
    {
        $post = (get_the_ID()) ? get_post(get_the_ID()) : (isset($_GET['postID']) ? get_post($_GET['postID']) : null);
        $tuloRestrictions = (get_post_meta($post->ID, 'is_premium', true)) ? get_post_meta($post->ID, 'is_premium', true) : '0';
        $shortcodeAlreadyExists = TuloPaywallApi::getInstance()->strContainsMulti($content, ['{{ PAYWALL LIMIT }}', '[paywall_limit]']);
        if (is_admin() || 'post' !== $post->post_type || $tuloRestrictions == '0' || $shortcodeAlreadyExists) {
            return $content;
        }

        $paywallLimit = "{{ PAYWALL LIMIT }}";
        $p1 = strpos($content, "</p>");
        if ($p1 !== false) {
            $content = substr_replace($content, '</p>' . $paywallLimit, $p1, 4);
        }
        return $content;
    }

    public function generateTuloShortcode($content)
    {
	    $post = (get_the_ID()) ? get_post(get_the_ID()) : get_post($_GET['postID']);
	    $tuloRestrictions = (get_post_meta($post->ID, 'is_premium', true)) ? get_post_meta($post->ID, 'is_premium', true) : '0';
		if($tuloRestrictions == '0') {
	        $shortcodeAlreadyExists = TuloPaywallApi::getInstance()->strContainsMulti($content, ['{{ PAYWALL LIMIT }}', '[paywall_limit]']);
			if($shortcodeAlreadyExists){
				$content = str_replace(['{{ PAYWALL LIMIT }}', '[paywall_limit]'], "", $content);
			}
			return $content;
		}

        $tuloMarkup = '<div id="tulo-paywall" class="mx-auto">
            <template id="paywall-loader-template">
                <div class="lds-dual-ring"></div><p><i>Loading ..</i></p>
            </template>
            <div id="paywall-container"></div>
        </div>';
        $find = ['{{ PAYWALL LIMIT }}', '[paywall_limit]'];
        $replacement = [$tuloMarkup, $tuloMarkup];

        foreach ($find as $f) {
            $pos = strpos($content, $f);
            if ($pos !== false) {
                $content = substr($content, 0, $pos + strlen($f));
            }
        }
        $content = str_replace($find, $replacement, $content);
        return $content;
    }

    public function registerEndpoint()
    {
        register_rest_route('bc/v1', '/post-content', array(
            array(
                'methods' => \WP_REST_Server::READABLE,
                'callback' => [$this, 'getPostContent'],
                'permission_callback' =>  '__return_true'
            ),
        ));
    }

    public function getPostContent($request)
    {
        $postID = $request->get_params()["postID"];
        $fullArticle = $this->removePaywallShortcodes(get_post($postID)->post_content);
		$fullArticle = $this->adsInject($fullArticle);

        $data = [
            'content' => $fullArticle
        ];

        return rest_ensure_response($data);
    }

	public function removePaywallShortcodes($fullArticle){
		$find = ['{{ PAYWALL LIMIT }}', '[paywall_limit]'];
		$replacement = ['', ''];
		$replaced = str_replace($find, $replacement, $fullArticle);
		return $replaced;
	}

	public function adsInject($fullArticle){
		$adsFind = [
			'/<!-- wp:bc-utility-blocks\/bc-container {"metadata":{"name":"LiveWrapped-desktop_in_article"},"className":"text-center my-8 mx-auto d-none d-md-block"} -->\n*\s*<!-- wp:bc-utility-blocks\/bc-container -->\n*\s*<!-- wp:html {"metadata":{"name":""}} -->\n*\s*Desktop ad in article\n*\s*<!-- \/wp:html -->\n*\s*<!-- \/wp:bc-utility-blocks\/bc-container -->\n*\s*<!-- \/wp:bc-utility-blocks\/bc-container -->/m',
			'/<!-- wp:bc-utility-blocks\/bc-container {"metadata":{"name":"LiveWrapped-mobile_in_article"},"className":"text-center my-8 mx-auto d-block d-md-none"} -->\n*\s*<!-- wp:bc-utility-blocks\/bc-container -->\n*\s*<!-- wp:html {"metadata":{"name":""}} -->\n*\s*Mobile ad in article\n*\s*<!-- \/wp:html -->\n*\s*<!-- \/wp:bc-utility-blocks\/bc-container -->\n*\s*<!-- \/wp:bc-utility-blocks\/bc-container -->/m'
		];
		// Use preg_replace_callback to dynamically generate a new ad with a unique UUID for each match
		$mobileAdCounter = 0; // Counter to track the mobile ad occurrences

		$fullArticle = preg_replace_callback($adsFind, function($matches) use (&$mobileAdCounter) {
			if (strpos($matches[0], 'LiveWrapped-desktop_in_article') !== false) {
				// For desktop ads, use the default placeholder creation
				return $this->createAdPlaceholder('desktop');
			} else {
				$mobileAdCounter++; // Increment mobile ad counter

				// Handle the first mobile ad differently
				if ($mobileAdCounter === 1) {
					return $this->createAdPlaceholder('mobile', 1); // Custom ad for the first mobile replacement
				} else {
					return $this->createAdPlaceholder('mobile', 2); // Default ad for subsequent mobile replacements
				}
			}
		}, $fullArticle);

		return $fullArticle;
	}

	public function createAdPlaceholder($device, $order = 2){
		$desktopAdPlaceholder = get_option("tulo_desktop_ad");
		$mobileAdPlaceholder = get_option("tulo_mobile_ad");

		switch ($device) {
			case 'desktop':
				$uuid = wp_generate_uuid4();
	            $escapedVarName = preg_replace('/[-_]/', '', $desktopAdPlaceholder);
				$placeholder = '<!-- Desktop in article -->
				<div class="bc-container LiveWrapped-desktop_in_article position-relative text-center my-8 mx-auto d-none d-md-block d-md-none d-lg-block wp-block-bc-utility-blocks-bc-container" style="min-width: 440px; min-height: 220px; height: auto;">
	            <div id="'.$desktopAdPlaceholder.'_'.$uuid.'" class="annons annons-text-before" data-esmg-sticky-duration="0"></div>
	            <script>
	            const ' . $escapedVarName . ' = () => {
					if ((typeof lwhbed !== \'undefined\') && (typeof liveWrappedSlotLoaded !== \'undefined\')) {
						if(screen.width > 768){
	                        console.log("' . $desktopAdPlaceholder . ' loaded!");
	                        lwhbed.cmd.push(function() {
	                            lwhbed.loadAd({tagId: "' . $desktopAdPlaceholder . '", callbackMethod: liveWrappedSlotLoaded});
	                        });
	                    }
					} else {
						// Retry after a short delay
						setTimeout(' . $escapedVarName . ', 100);
					}
				};
				' . $escapedVarName . '();
	            </script>
	            </div>';
				break;
			case 'mobile':
				$uuid = wp_generate_uuid4();
				$mobileAdPlaceholder = ($order == 1) ? str_replace("2", "1", $mobileAdPlaceholder) : $mobileAdPlaceholder;
				$escapedVarName = preg_replace('/[-_]/', '', $mobileAdPlaceholder);
				$placeholder = '<!-- Mobil '.$order.' Artikel -->
				<div class="bc-container LiveWrapped-mobile_in_article_'.$order.' position-relative d-block d-lg-none mx-auto text-center my-8 mx-auto d-block d-md-none wp-block-bc-utility-blocks-bc-container" style="min-width: 300px; min-height: 250px; height: auto;">
	                <div id="'.$mobileAdPlaceholder.'_'.$uuid.'" class="annons annons-text-before" data-esmg-sticky-duration="0"></div>
	                <script>
	                const ' . $escapedVarName . ' = () => {
					if ((typeof lwhbed !== \'undefined\') && (typeof liveWrappedSlotLoaded !== \'undefined\')) {
						if(screen.width <= 768){
	                        console.log("' . $mobileAdPlaceholder . ' loaded!");
	                        lwhbed.cmd.push(function() {
	                            lwhbed.loadAd({tagId: "' . $mobileAdPlaceholder . '", callbackMethod: liveWrappedSlotLoaded});
	                        });
	                    }
					} else {
						// Retry after a short delay
						setTimeout(' . $escapedVarName . ', 100);
					}
				};
				' . $escapedVarName . '();
	                </script>
	            </div>';
				break;
			default:
				$placeholder = '';
		}
		return $placeholder;
	}
}
