<?php

namespace TuloPaywayPaywall\Controllers;

use TuloPaywayPaywall\Models\TuloSettings;
use TuloPaywayPaywall\Config\TuloPaywayApi;

class TuloPayway
{
	/**
	 * @var string
	 */
    public string $paywayApiClient;
	/**
	 * @var string
	 */
    public string $tuloLoginSlug;
	/**
	 * @var string
	 */
    public string $tuloProfileSlug;
	/**
	 * @var string
	 */
    public string $paywayProfileUrl;
	/**
	 * @var string
	 */
    public string $paywayRegisterUrl;
	/**
	 * @var string
	 */
    public string $paywayForgotUrl;

	/**
	 * Class constructor
	 */
    public function __construct()
    {
		$this->paywayApiClient = TuloSettings::getInstance()->paywayApiClient;
		$this->tuloLoginSlug = TuloSettings::getInstance()->tuloLoginSlug;
		$this->tuloProfileSlug = TuloSettings::getInstance()->tuloProfileSlug;
        $this->paywayProfileUrl = TuloSettings::getInstance()->paywayProfileUrl;
        $this->paywayRegisterUrl = TuloSettings::getInstance()->paywayRegisterUrl;
        $this->paywayForgotUrl = TuloSettings::getInstance()->paywayForgotUrl;

	    add_action('wp_head', [$this, 'addIsAdminJsVar']);
        add_shortcode('tulo_authentication_buttons', [$this, 'tuloAuthShortcode']);
        add_shortcode('tulo_payway_login_form', [$this, 'tuloPaywayLoginForm']);
        add_shortcode('tulo_payway_register_form', [$this, 'tuloPaywayRegisterForm']);
        add_shortcode('tulo_payway_reset_password_form', [$this, 'tuloPaywayResetPasswordForm']);
        add_shortcode('tulo_new_password_form', [$this, 'tuloPaywayNewPasswordForm']);
	    add_shortcode('profile', [$this, 'userProfileShortcode']);
	    add_shortcode('about-me', [$this, 'userUpdateForm']);
	    add_shortcode('update-password', [$this, 'passwordUpdateForm']);
	    add_shortcode('subscription-info', [$this, 'subscriptionInfo']);
	    add_shortcode('cancel-subscription', [$this, 'cancelSubscription']);
        add_action('wp', [$this, 'checkLogoutSubmission']);
        add_action('wp', [$this, 'checkResetPasswordSubmission']);
//        add_action('wp', [$this, 'checkCancelSubscriptionSubmission']);
    }

	public function addIsAdminJsVar() {
		?>
		<script type="text/javascript">
			const isAdmin = <?php echo is_admin() ? 'true' : 'false'; ?>;
		</script>
		<?php
	}

    /**
     * Login/Logout menu buttons
     * @return string
     */
    public function tuloAuthShortcode()
    {
		$buttons = do_blocks('<!-- wp:template-part {"slug":"' . $this->tuloLoginSlug . '"} /-->');
        $buttons .= do_blocks('<!-- wp:template-part {"slug":"'.$this->tuloProfileSlug.'"} /-->');
		return $buttons;
    }

    /**
     * Login form shortcode
     * @return false|string
     */
    public function tuloPaywayLoginForm()
    {
        ob_start();
        ?>
        <div class="col col-lg-4 offset-lg-4">
            <h2 class="text-center mb-8">Logga in</h2>
	        <div id="tuloPaywayLoginFormAlert" class="d-none alert alert-success fade mx-3 my-6" role="alert">
		        <p class="m-0"></p>
	        </div>
            <form name="js_tuloPaywayLogin" class="js-tuloPaywayLogin mb-4" method="POST">
                <input type="hidden" name="tulo_payway_nonce" value="<?php
                echo wp_create_nonce('tulo_payway_login'); ?>">
                <div class="mb-6">
                    <div class="form-floating">
                        <input class="form-control text-bg-light" name="email" id="email" type="email" placeholder="E-postadress">
                        <label class="col-form-label" for="email">E-postadress</label>
                    </div>
                </div>
                <div class="mb-6">
                    <div class="form-floating">
                        <input class="form-control" name="password" id="password" type="password" placeholder="Lösenord">
                        <label class="col-form-label" for="password">Lösenord</label>
                    </div>
                </div>
                <div class="d-grid">
	                <button class="btn btn-lg btn-primary rounded-0 p-3" type="submit">
		                <span class="btn-label">Logga In</span>
		                <span class="d-none spinner-grow spinner-grow-sm" aria-hidden="true"></span>
		                <span class="d-none loader-label" role="status">Loggar in...</span>
	                </button>
                </div>
            </form>
            <p class="text-center mb-6">
                <a href="<?php echo TuloSettings::getInstance()->paywayForgotUrl; ?>">Glömt lösenord?</a>
            </p>
            <div class="container mb-6">
                <div class="custom-divider text-dark-2">
                    Inget konto?
                </div>
            </div>
            <p class="d-grid">
                <a class="btn btn-lg rounded-0 btn-outline-dark-2 p-3"
                   href="<?php echo TuloSettings::getInstance()->paywayRegisterUrl; ?>">Skapa konto</a>
            </p>
        </div>
	    <script>
            window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
			    'event' : 'login',
			    'userId' : ''
			});
	    </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Register form shortcode
     * @return false|string
     */
    public function tuloPaywayRegisterForm()
    {
        ob_start();
        ?>
        <div class="col-8 offset-2">
            <h2 class="text-center mb-8">Skapa konto</h2>
	        <div id="tuloPaywayRegisterAlert" class="d-none alert alert-success fade my-6" role="alert">
		        <p class="m-0"></p>
	        </div>
            <form name="registerForm" id="registerForm" class="js-tuloRegister mb-4" method="POST">
                <input type="hidden" name="tulo_payway_nonce" value="<?php
                echo wp_create_nonce('tulo_payway_register'); ?>">
	            <fieldset>
		            <legend class="text-primary">Personlig information</legend>
		            <div class="row">
			            <div class="col">
				            <div class="form-floating mb-3">
					            <input id="first_name" class="form-control" type="text" name="first_name" placeholder="Förnamn" required>
					            <label for="first_name">Förnamn</label>
				            </div>
			            </div>
			            <div class="col">
				            <div class="form-floating mb-3">
					            <input id="last_name" class="form-control" type="text" name="last_name" placeholder="Efternamn" value="" required>
					            <label for="last_name">Efternamn</label>
				            </div>
			            </div>
		            </div>
	            </fieldset>
	            <fieldset>
		            <legend class="text-primary">Kontaktinformation</legend>
	                <div class="mb-6">
	                    <div class="form-floating">
	                        <input class="form-control text-bg-light" name="email" id="email" type="text" placeholder="E-postadress" required>
	                        <label class="col-form-label" for="email">E-postadress</label>
	                    </div>
	                </div>
	                <div class="mb-6">
	                    <div class="form-floating">
	                        <input class="form-control" name="password" id="password" type="password" placeholder="Lösenord" required>
	                        <label class="col-form-label" for="password">Lösenord</label>
	                    </div>
	                </div>
	                <div class="mb-6">
	                    <div class="form-floating">
	                        <input class="form-control" name="confirm_password" id="confirm_password" type="password" placeholder="Repetera lösenord" required>
		                    <div class="invalid-feedback">
			                    Lösenord matchar inte
		                    </div>
		                    <label class="col-form-label" for="confirm_password">Repetera lösenord</label>
	                    </div>
	                </div>
	                <div class="mb-6 d-flex align-items-center gap-4">
	                    <input class="form-check-input mt-0" name="agreement" id="agreement" type="checkbox" required>
	                    <label class="form-check-label fs-9" for="agreement">Jag godkänner <a href="/cookie-policy/" target="_blank">cookiepolicy</a> och <a
	                            href="/hockeysveriges-sekretesspolicy/" target="_blank">personuppgiftspolicy</a></label>
	                </div>
	            </fieldset>
                <div class="d-grid">
	                <button class="btn btn-lg btn-primary rounded-0 p-3" type="submit">
		                <span class="btn-label">Skapa</span>
		                <span class="d-none spinner-grow spinner-grow-sm" aria-hidden="true"></span>
		                <span class="d-none loader-label" role="status">Registrering pågår...</span>
	                </button>
                </div>
            </form>
            <div class="container mb-6">
                <div class="custom-divider text-dark-2">
                    Redan medlem?
                </div>
            </div>
            <p class="d-grid">
                <a class="btn btn-lg rounded-0 btn-outline-dark-2 p-3" href="/logga-in/">Logga In</a>
            </p>
        </div>
	    <script>
		    const password = document.getElementById("password");
		    const confirm_password = document.getElementById("confirm_password");
			const agreement = document.getElementById("agreement");

		    function validateEmail(){
			    const email = document.getElementById("email");
			    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
			    if(!emailPattern.test(email.value)){
				    email.classList.remove('is-valid');
				    email.classList.add('is-invalid');
				    return false;
			    }else{
				    email.classList.remove('is-invalid');
				    email.classList.add('is-valid');
				    return true;
			    }
		    }

		    function validatePassword(){
			    if(password.value != confirm_password.value) {
				    confirm_password.classList.remove('is-valid');
				    confirm_password.classList.add('is-invalid');
				    return false;
			    } else {
				    confirm_password.classList.remove('is-invalid');
				    confirm_password.classList.add('is-valid');
				    return true;
			    }
		    }

			function validateAgreement(){
				if(agreement.checked == false){
					agreement.classList.replace('is-valid','is-invalid');
					return false;
				}
				agreement.classList.replace('is-invalid','is-valid');
				return true;
			}

		    const email = document.getElementById("email");
		    email.addEventListener("change", function(){
			    validateEmail();
		    });
		    email.addEventListener("keyup", function(){
			    validateEmail();
		    });

		    password.onchange = validatePassword;
		    confirm_password.onkeyup = validatePassword;
		    document.forms.namedItem("registerForm").addEventListener("submit", (e)=>{
			    e.preventDefault();
			    // if(validatePassword() && validateAgreement()){
				//     e.target.submit();
			    // }
		    });
	    </script>
        <?php
        return ob_get_clean();
    }

	/**
     * Reset Password form shortcode
     * @return false|string
     */
    public function tuloPaywayResetPasswordForm()
    {
        ob_start();
        ?>
        <div class="col-4 offset-4">
            <h2 class="text-center mb-8">Glömt lösenord</h2>
	        <div id="tuloPaywayResetPasswordFormAlert" class="d-none alert alert-success fade my-6" role="alert">
		        <p class="m-0"></p>
	        </div>
            <form name="js_tuloResetPassword" class="js-tuloResetPassword mb-4" method="POST">
                <input type="hidden" name="tulo_payway_nonce" value="<?php
                echo wp_create_nonce('tulo_payway_reset_password'); ?>">
                <div class="mb-6">
                    <div class="form-floating">
                        <input class="form-control text-bg-light" name="email" id="email" type="text" placeholder="E-postadress" <?php echo (isset
                        ($_POST['email'])) ? 'value="'.$_POST['email'].'"' : ""; ?>
                        )" required>
                        <label class="col-form-label" for="email">E-postadress</label>
                    </div>
                </div>
                <div class="d-grid">
                    <input class="btn btn-lg btn-primary rounded-0 p-3 fs-7" type="submit" value="Återställa"/>
                </div>
            </form>
            <div class="container mb-6">
                <div class="custom-divider text-dark-2">
	                Inget konto?
                </div>
            </div>
            <p class="d-grid">
	            <a class="btn btn-lg rounded-0 btn-outline-dark-2 p-3"
	               href="<?php echo TuloSettings::getInstance()->paywayRegisterUrl; ?>">Skapa konto</a>
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

	/**
     * New Password form shortcode
     * @return false|string
     */
    public function tuloPaywayNewPasswordForm()
    {
        ob_start();
        ?>
        <div class="col-4 offset-4">
            <h2 class="text-center mb-8">Nytt lösenord</h2>
	        <div id="tuloPaywayNewPasswordFormAlert" class="d-none alert alert-success fade mx-3 my-6" role="alert">
		        <p class="m-0"></p>
	        </div>
            <form name="resetPassword" class="js-tuloNewPassword mb-4" method="POST">
                <input type="hidden" name="tulo_payway_nonce" value="<?php
                echo wp_create_nonce('tulo_payway_new_password'); ?>">
                <input type="hidden" name="tulo_access_token" value="<?php echo TuloPaywayApi::getInstance()->getNewServiceToken()['access_token']; ?>">
                <input type="hidden" name="email" value="<?php echo $_GET['email']; ?>">
	            <div class="row">
		            <div class="col">
			            <div class="form-floating mb-3">
				            <input class="form-control" id="password" type="password" name="password" placeholder="Nytt lösenord" required>
				            <label for="password">Lösenord</label>
			            </div>
		            </div>
	            </div>
	            <div class="row">
		            <div class="col">
			            <div class="form-floating mb-3">
				            <input class="form-control is-invalid" id="confirm_password" type="password" name="confirm_password" placeholder="Bekräfta
								lösenord" required>
				            <div class="invalid-feedback">
					            Lösenord matchar inte
				            </div>
				            <label for="confirm_password">Bekräfta lösenord</label>
			            </div>
		            </div>
	            </div>
                <div class="d-grid">
                    <input class="btn btn-lg btn-primary rounded-0 p-3 fs-7" type="submit" value="Spara"/>
                </div>
            </form>
        </div>
	    <script>
		    const password = document.getElementById("password");
		    const confirm_password = document.getElementById("confirm_password");

		    function validatePassword(){
			    if(password.value != confirm_password.value) {
				    confirm_password.classList.replace('is-valid','is-invalid');
				    return false;
			    } else {
				    confirm_password.classList.replace('is-invalid','is-valid');
				    return true;
			    }
		    }
		    password.onkeyup = validatePassword;
		    confirm_password.onkeyup = validatePassword;
		    document.forms.namedItem("resetPassword").addEventListener("submit", (e)=>{
			    e.preventDefault();
			    if(validatePassword()){
				    e.target.submit();
			    }
		    });
	    </script>
        <?php
        return ob_get_clean();
    }

	/**
	 * @return false|string
	 */
	public function userProfileShortcode() {
		ob_start(); ?>
		<ul class="nav nav-pills mb-3" id="mitt-konto" role="tablist">
			<li class="nav-item" role="presentation">
				<button class="nav-link active" id="about-me-tab" data-bs-toggle="pill" data-bs-target="#about-me" type="button" role="tab"
				        aria-controls="about-me" aria-selected="true">Om mig</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="update-password-tab" data-bs-toggle="pill" data-bs-target="#update-password" type="button" role="tab" aria-controls="update-password" aria-selected="false">Ändra lösenord</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="subscription-info-tab" data-bs-toggle="pill" data-bs-target="#subscription-info" type="button" role="tab" aria-controls="subscription-info" aria-selected="false">Mina prenumerationer</button>
			</li>
		</ul>
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="about-me" role="tabpanel" aria-labelledby="about-me-tab" tabindex="0">
				<?php echo do_shortcode('[about-me]'); ?>
			</div>
			<div class="tab-pane fade" id="update-password" role="tabpanel" aria-labelledby="update-password-tab" tabindex="0">
				<p class="my-5 ms-0 ms-lg-5">Ditt nya lösenord måste vara minst 6 tecken långt och helst innehålla både siffror och bokstäver. Vi lagrar ditt lösenord krypterat.</p>
				<?php echo do_shortcode('[update-password]'); ?>
			</div>
			<div class="tab-pane fade" id="subscription-info" role="tabpanel" aria-labelledby="subscription-info-tab" tabindex="0">
				<?php echo do_shortcode('[subscription-info]'); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * @return false|string
	 */
	public function userUpdateForm() {
		ob_start(); ?>
		<div>
			<div id="userUpdateFormAlert" class="d-none alert alert-success fade mx-3 my-6" role="alert">
				<p class="m-0"></p>
			</div>
			<form name="profileForm" id="profileForm" class="px-3 py-5" method="POST" action="#about-me">
				<input type="hidden" name="tulo_payway_nonce" value="<?php
				echo wp_create_nonce('tulo_payway_update_user'); ?>">
				<fieldset>
					<legend class="text-primary">Personlig information</legend>
					<div class="row">
						<div class="col">
							<div class="form-floating mb-3">
								<input id="first_name" class="form-control" type="text" name="first_name" placeholder="Förnamn" required>
								<label for="first_name">Förnamn</label>
							</div>
						</div>
						<div class="col">
							<div class="form-floating mb-3">
								<input id="last_name" class="form-control" type="text" name="last_name" placeholder="Efternamn" value="" required>
								<label for="last_name">Efternamn</label>
							</div>
						</div>
					</div>
					<div class="form-floating mb-3">
						<input class="form-control" id="email" type="email" name="email" placeholder="name@example.com" value="" disabled>
						<label for="email">E-post</label>
					</div>
					<div class="form-floating mb-3">
						<input class="form-control" id="birth_date" type="date" name="birth_date" placeholder="YYYY-MM-DD" value="" pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}$" required>
						<label for="age">Födelsedatum</label>
					</div>
					<div class="form-floating mb-3">
						<input class="form-control" id="mobile_phone_number" type="text" name="mobile_phone_number" placeholder="mobilnummer" value="" pattern="\+?[0-9]{9,}" required>
						<label for="mobile_phone_number">mobilnummer (ENDAST SIFFROR EX. +701231234)</label>
					</div>
				</fieldset>
				<fieldset>
					<legend class="text-primary">Adress</legend>
					<div class="row">
						<div class="col-9">
							<div class="form-floating mb-3">
								<input id="address[street]" class="form-control" type="text" name="address[street]" placeholder="Gatuadress" value="" required>
								<label for="address[street]">Gatuadress</label>
							</div>
						</div>
						<div class="col-3">
							<div class="form-floating mb-3">
								<input id="address[street_number]" class="form-control" type="number" name="address[street_number]" placeholder="Gatunummer"
								       min="0" value="" required>
								<label for="address[street_number]">Gatunummer</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-4">
							<div class="form-floating mb-3">
								<input id="address[zip_code]" class="form-control" type="text" name="address[zip_code]" placeholder="postnummer" value=""
								       pattern="\d{2,10}"
								       oninvalid="this.setCustomValidity('Postnummer ska vara nummer')"
								       oninput="this.setCustomValidity('')"
								       required>
								<label for="address[zip_code]">Postnummer</label>
							</div>
						</div>
						<div class="col-4">
							<div class="form-floating mb-3">
								<input id="address[city]" class="form-control" type="text" name="address[city]" placeholder="Stad" value="" required>
								<label for="address[city]">Stad</label>
							</div>
						</div>
						<div class="col-4">
							<div class="form-floating mb-3">
								<input id="address[country_code]" class="form-control" type="text" name="address[country_code]" placeholder="SE" value=""
								       pattern="[a-zA-Z]{2}"
								       oninvalid="this.setCustomValidity('Landskoden ska vara 2 tecken')"
								       oninput="this.setCustomValidity('')"
								       required>
								<label for="address[country_code]">Landskod</label>
							</div>
						</div>
					</div>
				</fieldset>
				<div class="d-grid mt-5">
					<button class="btn btn-lg btn-primary rounded-0 p-3" type="submit">
						<span class="btn-label">Spara</span>
						<span class="d-none spinner-grow spinner-grow-sm" aria-hidden="true"></span>
						<span class="d-none loader-label" role="status">Uppdaterar...</span>
					</button>
				</div>
			</form>
		</div>
		<script>
			fields = document.forms.profileForm.querySelectorAll('input');
			fields.forEach((field) => {
				switch (field.getAttribute('id')) {
					case 'first_name':
						field.value = localStorage.getItem('tulo_account_first_name');
						break;
					case 'last_name':
						field.value = localStorage.getItem('tulo_account_last_name');
						break;
					case 'email':
						field.value = localStorage.getItem('tulo_account_email');
						break;
					case 'birth_date':
						field.value = localStorage.getItem('tulo_account_birth_date');
						break;
					case 'mobile_phone_number':
						field.value = localStorage.getItem('tulo_account_mobile_phone_number');
						break;
					case 'address[street]':
						field.value = JSON.parse(localStorage.getItem('tulo_account_address')).street;
						break;
					case 'address[street_number]':
						field.value = JSON.parse(localStorage.getItem('tulo_account_address')).street_number;
						break;
					case 'address[zip_code]':
						field.value = JSON.parse(localStorage.getItem('tulo_account_address')).zip_code;
						break;
					case 'address[city]':
						field.value = JSON.parse(localStorage.getItem('tulo_account_address')).city;
						break;
					case 'address[country_code]':
						field.value = JSON.parse(localStorage.getItem('tulo_account_address')).country_code;
						break;
				}
			});
		</script>
		<?php
		return ob_get_clean();
	}

	/**
	 * @return false|string
	 */
	public function passwordUpdateForm() {
		ob_start(); ?>
		<div>
			<div id="passwordUpdateFormAlert" class="d-none alert alert-success fade mx-3 my-6" role="alert">
				<p class="m-0">Ditt lösenord har uppdaterats.</p>
			</div>
			<form name="updatePassword" id="updatePassword" class="px-3 py-5" method="POST" action="#update-password">
				<input type="hidden" name="tulo_payway_nonce" value="<?php
				echo wp_create_nonce('tulo_payway_update_password'); ?>">
				<fieldset>
					<div class="row">
						<div class="col">
							<div class="form-floating mb-3">
								<input class="form-control" id="old_password" type="password" name="old_password" placeholder="Gammalt lösenord" required>
								<label for="password">Gammalt lösenord</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-6">
							<div class="form-floating mb-3">
								<input class="form-control" id="password" type="password" name="password" placeholder="Nytt lösenord" required>
								<label for="password">Lösenord</label>
							</div>
						</div>
						<div class="col-6">
							<div class="form-floating mb-3">
								<input class="form-control is-invalid" id="confirm_password" type="password" name="confirm_password" placeholder="Bekräfta
								lösenord" required>
								<div class="invalid-feedback">
									Lösenord matchar inte
								</div>
								<label for="confirm_password">Bekräfta lösenord</label>
							</div>
						</div>
					</div>
				</fieldset>
				<div class="d-grid mt-5">
					<button class="btn btn-lg btn-primary rounded-0 p-3" type="submit">
						<span class="btn-label">Spara</span>
						<span class="d-none spinner-grow spinner-grow-sm" aria-hidden="true"></span>
						<span class="d-none loader-label" role="status">Uppdaterar...</span>
					</button>
				</div>
			</form>
		</div>
		<script>
			const password = document.getElementById("password");
			const confirm_password = document.getElementById("confirm_password");

			function validatePassword(){
				if(password.value != confirm_password.value) {
					confirm_password.classList.replace('is-valid','is-invalid');
					return false;
				} else {
					confirm_password.classList.replace('is-invalid','is-valid');
					return true;
				}
			}
			password.onkeyup = validatePassword;
			confirm_password.onkeyup = validatePassword;
			document.forms.namedItem("updatePassword").addEventListener("submit", (e)=>{
				e.preventDefault();
			});
		</script>
		<?php
		return ob_get_clean();
	}

	/**
	 * @return false|string
	 */
	public function subscriptionInfo() {
		ob_start(); ?>
		<div class="px-3 py-5">
			<h4 class="text-primary ms-4">Prenumerationer</h4>
			<div id="no-product" class="my-5">
				<div class="card border-0">
					<div class="row g-0 align-items-center">
						<div class="col-md-8">
							<div class="card-body">
								<div class="card-text">
									<p class="text-muted">Inga prenumerationer.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="products" class="my-5"></div>
		</div>
		<div class="px-3 py-5">
			<h4 class="text-primary ms-4">Betalningar och kvitton</h4>
			<div class="table-responsive">
				<table id="purchase-history" class="table table-hover fs-10">
					<thead>
					<tr class="fs-10 text-muted">
						<th scope="col">DATUM</th>
						<th scope="col">BESKRIVNING</th>
						<th scope="col">REFERENS</th>
						<th scope="col">PRIS</th>
						<th scope="col">Transaktions Id</th>
						<th scope="col">Betalsätt</th>
						<th scope="col">BETALNINGSSTATUS</th>
					</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * @return false|string
	 */
	public function cancelSubscription() {
		if(!isset($_GET['customer_can_cancel']) && !is_admin()){
			header("Location: /mitt-konto/#subscription-info");
			exit;
		}
		ob_start(); ?>
		<div class="px-3 py-5">
			<h2 class="text-primary text-center">Bekräfta avslut av prenumeration</h2>
			<div id="no-product" class="my-5">
				<div class="card border-0">
					<div class="card-body">
						<div class="card-text">
							<p class="text-center">Vill du verkligen avsluta din prenumeration, vänligen bekräfta</p>
							<form class="text-center mt-10" name="cancelSubscription" id="cancelSubscription" method="POST" action="#cancel-subscription">
								<button class="btn btn-lg btn-primary rounded-0 p-3" type="submit">
									<span class="btn-label">Bekräfta</span>
									<span class="d-none spinner-grow spinner-grow-sm" aria-hidden="true"></span>
									<span class="d-none loader-label" role="status">Uppdaterar...</span>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 *
	 * Process logout form after submission
	 *
	 * @return void
	 */
	public function checkLogoutSubmission()
	{
		if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tulo_payway_nonce']) && $_POST['tulo_payway_nonce'] == 'tulo_payway_logout') {
			$response = TuloPaywayApi::getInstance()->successRemoteLogout();
		}//end if
	}

	/**
	 *
	 * Process reset password form after submission
	 *
	 * @return void
	 */
	public function checkResetPasswordSubmission()
	{
		if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tulo_payway_nonce']) && wp_verify_nonce($_POST['tulo_payway_nonce'], 'tulo_payway_reset_password')) {
			$confirmationCode = TuloPaywayApi::getInstance()->requestPasswordResetToken($_POST['email']);
			if($confirmationCode){
				echo "<script id=\"passwordreset-request\">
				(async () => {
					window.addEventListener('DOMContentLoaded', event => {
						localStorage.setItem('tulo_confirmation_code', '".$confirmationCode."');
						const alertBox = document.getElementById('tuloPaywayResetPasswordFormAlert');
						const errorMessage = alertBox.querySelector('p');
						errorMessage.innerHTML = 'Om din e-postadress matchar med ett konto kommer du få ett mail med instruktioner.';
						alertBox.classList.replace('alert-danger', 'alert-success');
						alertBox.classList.replace('d-none', 'show');
					});
				})();
				</script>";
			}
		}

		if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tulo_payway_nonce']) && wp_verify_nonce($_POST['tulo_payway_nonce'], 'tulo_payway_new_password')) {
			if(!isset($_GET['cc'])){
				header("Location: " . get_bloginfo('url').TuloSettings::getInstance()->paywayForgotUrl.'?without-cc');
				exit;
			}
			$confirmationCode = $_GET['cc'];
			$email = $_GET['email'];
			$password = $_POST['password'];
			$userAccount = TuloPaywayApi::getInstance()->getUserAccount();
			if ($userAccount) {
				$userId = $userAccount['item']['id'];
				if(TuloPaywayApi::getInstance()->completePasswordReset($userId, $confirmationCode, $password)) {
//					$_SESSION['session_success'] = "Ditt lösenord har ändrats. Du kan nu logga in med det nya lösenordet.";
					header("Location: " . get_bloginfo('url').'/logga-in/?user-id='.$userId.'&passReset=OK');
					exit;
				}
			} else {
				echo "<script>
				(() => {
					window.addEventListener('DOMContentLoaded', event => {
						const alertBox = document.getElementById('tuloPaywayNewPasswordFormAlert');
						const errorMessage = alertBox.querySelector('p');
						errorMessage.innerHTML = 'Något gick fel, försök igen senare.';
						alertBox.classList.replace('alert-success', 'alert-danger');
						alertBox.classList.replace('d-none', 'show');
					});
				})();
				</script>";
			}//end if
		}
	}

	/**
	 *
	 * Process cancel subscription form after submission
	 *
	 * @return void
	 */
//	public function checkCancelSubscriptionSubmission() {
//		if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tulo_payway_nonce']) && wp_verify_nonce($_POST['tulo_payway_nonce'], 'tulo_payway_cancel_subscription')) {
//
//		}
//	}
}
