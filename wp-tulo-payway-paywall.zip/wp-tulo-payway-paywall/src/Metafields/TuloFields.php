<?php

namespace TuloPaywayPaywall\Metafields;

/**
 * Class BCFields
 */
class TuloFields
{
    /**
     * BCFields constructor.
     */
    public function __construct()
    {
        require_once get_stylesheet_directory() . '/bc-fields/autoload.php';
        $this->initMetaFields();
    }

    /**
     * @return void
     */
    public function initMetaFields()
    {
	    TuloMetaFields::getInstance()->init();
    }
}
