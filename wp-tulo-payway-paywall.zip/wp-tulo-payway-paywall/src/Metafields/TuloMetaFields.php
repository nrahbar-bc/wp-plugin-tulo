<?php

namespace TuloPaywayPaywall\Metafields;

use BCFields\Facades\BCFieldsMetabox;

class TuloMetaFields extends BCFieldsMetabox{

	/**
	 * @return void
	 */
	public function init()
	{
		$this->register(
			'post_paywall_meta',
			esc_html__('Paywall Setting', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN),
			['post'],
			'side',
			'high'
		)
			->addSelectField(
				'is_premium',
				esc_html__('Is Premium?', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN),
				[
					0 => esc_html__('Open For All', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN),
					2 => esc_html__('Require Free Account', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN),
					1 => esc_html__('Premium Account', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN),
				],
			);
	}
}
