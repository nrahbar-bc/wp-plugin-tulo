<?php

namespace TuloPaywayPaywall\Models;

use TuloPaywayPaywall\Admin\TuloSettingsPage;
use TuloPaywayPaywall\Traits\SingletonTrait;

/**
 * Class ChildThemeSettings
 */
class TuloSettings {
    use SingletonTrait;

    public $paywayApiClient;
    public $paywayApiSecret;
    public $paywayApiUrl;
    public $paywayRedirectUrl;
    public $paywayOrganizationId;
    public $paywayProductKey;
    public $paywayPaywallKey;
    public $paywayProfileUrl;
    public $paywayRegisterUrl;
    public $paywayShopUrl;
    public $paywayForgotUrl;
    public $paywallApiKey;
    public $paywallApiSecret;
    public $paywallApiUrl;
    public $paywallTitle;
    public $tuloLoginSlug;
    public $tuloProfileSlug;
    public $tuloClientArea;
    public $tuloDesktopAd;
    public $tuloMobileAd;
    public $tuloLoginClasses;
    public $rudderstackWriteKey;

    /**
     * Constructor
     */
    private function __construct()
    {
        $this->loadTuloSettingsData();
    }

    /**
     * Load model properties with settings data
     * @return void
     */
    public function loadTuloSettingsData()
    {
        $this->paywayApiClient = (string) get_option(TuloSettingsPage::PAYWAY_API_CLIENT);
        $this->paywayApiSecret = (string) get_option(TuloSettingsPage::PAYWAY_API_SECRET);
        $this->paywayApiUrl = (string) get_option(TuloSettingsPage::PAYWAY_API_URL);
        $this->paywayRedirectUrl = (string) get_option(TuloSettingsPage::PAYWAY_REDIRECT_URL);
        $this->paywayOrganizationId = (string) get_option(TuloSettingsPage::PAYWAY_ORGANIZATION_ID);
        $this->paywayProductKey = (string) get_option(TuloSettingsPage::PAYWAY_PRODUCT_KEY);
        $this->paywayPaywallKey = (string) get_option(TuloSettingsPage::PAYWAY_PAYWALL_KEY);
        $this->paywayProfileUrl = (string) get_option(TuloSettingsPage::PAYWAY_PROFILE_URL);
        $this->paywayRegisterUrl = (string) get_option(TuloSettingsPage::PAYWAY_REGISTER_URL);
        $this->paywayShopUrl = (string) get_option(TuloSettingsPage::PAYWAY_SHOP_URL);
        $this->paywayForgotUrl = (string) get_option(TuloSettingsPage::PAYWAY_FORGOT_URL);
        $this->paywallApiKey = (string) get_option(TuloSettingsPage::PAYWALL_API_KEY);
        $this->paywallApiSecret = (string) get_option(TuloSettingsPage::PAYWALL_API_SECRET);
        $this->paywallApiUrl = (string) get_option(TuloSettingsPage::PAYWALL_API_URL);
        $this->paywallTitle = (string) get_option(TuloSettingsPage::PAYWALL_TITLE);
        $this->tuloLoginSlug = (string) get_option(TuloSettingsPage::TULO_LOGIN_SLUG);
        $this->tuloProfileSlug = (string) get_option(TuloSettingsPage::TULO_PROFILE_SLUG);
        $this->tuloClientArea = (string) get_option(TuloSettingsPage::TULO_CLIENT_AREA);
        $this->tuloDesktopAd = (string) get_option(TuloSettingsPage::TULO_DESKTOP_AD);
        $this->tuloMobileAd = (string) get_option(TuloSettingsPage::TULO_MOBILE_AD);
        $this->tuloLoginClasses = (string) get_option(TuloSettingsPage::TULO_LOGIN_CLASSES);
        $this->rudderstackWriteKey = (string) get_option(TuloSettingsPage::RUDDERSTACK_WRITE_KEY);
    }
}
