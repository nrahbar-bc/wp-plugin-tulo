<?php

namespace TuloPaywayPaywall\Shortcodes;

use TuloPaywayPaywall\Models\TuloSettings;

class PaywallShortcode {
	/**
	 * @return void
	 */
	public function __construct() {
		add_shortcode('paywall_limit', [$this, 'renderPaywallLimit']);
		add_shortcode('tulo-pluginUrl', [$this, 'tuloPluginUrl']);
		add_shortcode('tulo-paywayProfileUrl', [$this, 'paywayProfileUrl']);
	}

	public function renderPaywallLimit() {
		return '{{ PAYWALL LIMIT }}';
	}

	public function tuloPluginUrl() {
		return TULO_PAYWAY_PAYWALL_URL;
	}

	public function paywayProfileUrl() {
		return TuloSettings::getInstance()->paywayProfileUrl;
	}
}
