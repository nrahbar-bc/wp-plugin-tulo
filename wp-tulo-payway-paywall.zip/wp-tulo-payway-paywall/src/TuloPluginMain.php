<?php

namespace TuloPaywayPaywall;

use TuloPaywayPaywall\Admin\TuloSettingsPage;
use TuloPaywayPaywall\Config\TuloPaywallApi;
use TuloPaywayPaywall\Config\TuloPaywayApi;
use TuloPaywayPaywall\Controllers\TuloPaywall;
use TuloPaywayPaywall\Controllers\TuloPayway;
use TuloPaywayPaywall\Controllers\Enqueue;
use TuloPaywayPaywall\Metafields\TuloFields;
use TuloPaywayPaywall\Shortcodes\PaywallShortcode;

class TuloPluginMain {
	public function __construct() {
		if(is_admin()){
			new TuloSettingsPage();
			add_filter('plugin_action_links', [$this, 'addPluginLink'], 10, 2);
		}
		new TuloFields();
		new Enqueue();
		new PaywallShortcode();
		new TuloPayway();
		new TuloPaywayApi();
		new TuloPaywallApi();
		new TuloPaywall();
	}

	public function addPluginLink($pluginActions, $pluginFile ) {
		$newActions = array();
		if ( 'wp-tulo-payway-paywall/wp-tulo-payway-paywall.php' === $pluginFile ) {
			$newActions['cl_settings'] = sprintf(
				__( '<a href="%s">Settings</a>', TULO_PAYWAY_PAYWALL_TEXT_DOMAIN ),
				esc_url( admin_url('admin.php?page=tulo-settings'))
			);
		}
		return array_merge( $newActions, $pluginActions );
	}
}
