<?php
/**
 * Plugin Name:     Tulo Payway and Paywall
 * Plugin URI:      https://github.com/BetterCollective/bc-scraps/tree/master/wp-tulo-payway-paywall
 * Description:     Tulo functionalities, WordPress integration
 * Author:          Nima Rahbar
 * Author URI:      https://bc.rocks/profile/?uid=1101
 * Slug:            wp-tulo-payway-paywall
 * Text Domain:     wp-tulo-payway-paywall
 * Domain Path:     /languages
 * Version:         0.6.1
 *
 * @package Wp_Tulo_Payway_Paywall
 */

use TuloPaywayPaywall\TuloPluginMain;

require_once __DIR__.'/vendor/autoload.php';

if( !function_exists('get_plugin_data') ){
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$pluginData = get_file_data(__FILE__, ['Version' => 'Version']);
define('TULO_PAYWAY_PAYWALL_VERSION', $pluginData['Version']);

define('TULO_PAYWAY_PAYWALL_URL', plugin_dir_url(__FILE__));
const TULO_PAYWAY_PAYWALL_DIR         = __DIR__;
const TULO_PAYWAY_PAYWALL_TEXT_DOMAIN = 'wp-tulo-payway-paywall';

// Check for updates
require 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://raw.githubusercontent.com/nrahbar-bc/wp-plugin-tulo/refs/heads/master/wp-tulo-payway-paywall.json',
    __FILE__, //Full path to the main plugin file or functions.php.
    'wp-tulo-payway-paywall'
);

new TuloPluginMain();
